// ═══════════════════════════════════════════════
//  TRANSLATIONS
// ═══════════════════════════════════════════════
const T = {
  en:{
    sub:'PDF · EPUB · MOBI · 1.10v', donate:'Donate ♥',
    tabSearch:'Search', tabHistory:'History', tabFavorites:'Favorites', tabSettings:'Settings',
    placeholder:'Search books, files...', searchBtn:'Search',
    filterAll:'All', worksOn:'Works on',
    historyTitle:'Recent searches', clearAll:'Clear all', historyEmpty:'No searches yet', welcomeTitle:'Welcome to Toilet Finder', welcomeSub:'Search for any book or document below. Here are some ideas to get started:', favsWelcomeTitle:'No favorites yet', favsWelcomeSub:'Star any search from history to save it here.', queryPreviewLabel:'Search:',
    favsTitle:'Saved favorites', favsEmpty:'No favorites yet',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Appearance', labelDark:'Dark mode', labelAccent:'Accent color (only available in Light Mode)',
    labelLang:'Interface language', labelEngine:'Search engine',
    labelDev:'Developer mode', labelDevToggle:'Enable developer mode',
    labelCustom:'Custom URL', saveBtn:'Save', savedMsg:'✓ Saved',
    labelShortcuts:'Keyboard shortcuts',
    scSearch:'Run search', scFocus:'Focus search', scTabs:'Switch tabs',
    scFilters:'Cycle filters', scClose:'Close popup', scCopy:'Copy query',
    confirmTitle:'Clear history?', confirmBody:'This will permanently delete all your search history.',
    cancel:'Cancel', confirmOk:'Clear',
    previewTitle:'Top result preview', previewOpen:'Open in browser',
    previewLoading:'Loading preview...', previewError:'Preview not available.',
    close:'Close',
    flashTab:(n)=>`Tab ${n}`, flashFilter:(f)=>`Filter: ${f}`, flashCopy:'Query copied!',
    flashFav:'Added to favorites ★', flashUnfav:'Removed from favorites',
    libsLabel:'Direct search',
    exportBtn:'↓ Export JSON', importBtn:'Import', labelDataIO:'History data', importPlaceholder:'Paste JSON to import…',
    importSuccess:(n)=>`Imported ${n} entries`, importError:'Invalid JSON',
    statsChip:(n)=>`${n} search${n===1?'':'es'}`,
    isbnDetected:'ISBN detected',
    isbnPill:(isbn)=>`ISBN ${isbn}`,
    isbnSearchAnnas:"Anna's", isbnSearchLibgen:'LibGen', isbnSearchOpenlib:'OpenLib',
    authorLabel:'Search by author', authorLabelShort:'By', authorPlaceholder:'Author name…',
    scAuthor:'Focus author', badgeTitle:(n)=>`${n} searches`,
    devWarning:"These links may not work correctly. Sites like Z-Library change domains frequently and may be blocked in your region.",
    ctxUse:'Use this', ctxBanner:(q)=>`Selected: ${q}`,
    labelShowAuthor:'Show author field', labelShowStats:'Show search counter', labelFocusMode:'Focus mode', labelDevTimestamps:'Exact timestamps', labelDevQueryPreview:'Query preview', copyJsonBtn:'{ } Copy as JSON', authorChipAccept:'Move to author', authorChipLabel:(a)=>`Author detected: "${a}"`, favLabelRead:'📖 Reading', favLabelDone:'✅ Downloaded', favLabelPending:'🔍 Pending', favSortAlpha:'A→Z', favSortDate:'By date', lastSearchLabel:'Search again:',
    labelAutoDark:'Follow system theme', labelCompact:'Compact mode',
    historySearchPlaceholder:'Filter history…', historyNoResults:'No matches',
    scCompact:'Toggle compact', sub:'PDF · EPUB · MOBI · 1.10v',
  },
  es:{
    sub:'PDF · EPUB · MOBI · 1.10v', donate:'Donar ♥',
    tabSearch:'Buscar', tabHistory:'Historial', tabFavorites:'Favoritos', tabSettings:'Ajustes',
    placeholder:'Buscar libros, archivos...', searchBtn:'Buscar',
    filterAll:'Todo', worksOn:'Compatible con',
    historyTitle:'Búsquedas recientes', clearAll:'Borrar todo', historyEmpty:'Sin búsquedas aún', welcomeTitle:'Bienvenido a Toilet Finder', welcomeSub:'Busca cualquier libro o documento abajo. Algunas ideas para empezar:', favsWelcomeTitle:'Sin favoritos aún', favsWelcomeSub:'Marca con ★ cualquier búsqueda del historial para guardarla aquí.', queryPreviewLabel:'Búsqueda:',
    favsTitle:'Favoritos guardados', favsEmpty:'Sin favoritos aún',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Apariencia', labelDark:'Modo oscuro', labelAccent:'Color de acento (solo en Modo Claro)',
    labelLang:'Idioma de la interfaz', labelEngine:'Motor de búsqueda',
    labelDev:'Modo desarrollador', labelDevToggle:'Activar modo desarrollador',
    labelCustom:'URL personalizada', saveBtn:'Guardar', savedMsg:'✓ Guardado',
    labelShortcuts:'Atajos de teclado',
    scSearch:'Buscar', scFocus:'Enfocar búsqueda', scTabs:'Cambiar pestañas',
    scFilters:'Ciclar filtros', scClose:'Cerrar popup', scCopy:'Copiar búsqueda',
    confirmTitle:'¿Borrar historial?', confirmBody:'Se eliminará permanentemente todo el historial.',
    cancel:'Cancelar', confirmOk:'Borrar',
    previewTitle:'Vista previa', previewOpen:'Abrir en navegador',
    previewLoading:'Cargando...', previewError:'Vista previa no disponible.',
    close:'Cerrar',
    flashTab:(n)=>`Pestaña ${n}`, flashFilter:(f)=>`Filtro: ${f}`, flashCopy:'¡Query copiada!',
    flashFav:'Añadido a favoritos ★', flashUnfav:'Eliminado de favoritos',
    libsLabel:'Búsqueda directa',
    exportBtn:'↓ Exportar JSON', importBtn:'Importar', labelDataIO:'Datos del historial', importPlaceholder:'Pega el JSON para importar…',
    importSuccess:(n)=>`${n} entradas importadas`, importError:'JSON inválido',
    statsChip:(n)=>`${n} búsqueda${n===1?'':'s'}`,
    isbnDetected:'ISBN detectado',
    isbnPill:(isbn)=>`ISBN ${isbn}`,
    isbnSearchAnnas:"Anna's", isbnSearchLibgen:'LibGen', isbnSearchOpenlib:'OpenLib',
    authorLabel:'Buscar por autor', authorLabelShort:'Por', authorPlaceholder:'Nombre del autor…',
    scAuthor:'Enfocar autor', badgeTitle:(n)=>`${n} búsquedas`,
    devWarning:"Estos enlaces pueden no funcionar correctamente. Sitios como Z-Library cambian de dominio con frecuencia y pueden estar bloqueados en tu región.",
    ctxUse:'Usar', ctxBanner:(q)=>`Seleccionado: ${q}`,
    labelShowAuthor:'Mostrar campo de autor', labelShowStats:'Mostrar contador de búsquedas', labelFocusMode:'Modo foco', labelDevTimestamps:'Timestamps exactos', labelDevQueryPreview:'Vista previa de query', copyJsonBtn:'{ } Copiar como JSON', authorChipAccept:'Mover a autor', authorChipLabel:(a)=>`Autor detectado: "${a}"`, favLabelRead:'📖 Leyendo', favLabelDone:'✅ Descargado', favLabelPending:'🔍 Pendiente', favSortAlpha:'A→Z', favSortDate:'Por fecha', lastSearchLabel:'Buscar de nuevo:',
    labelAutoDark:'Seguir tema del sistema', labelCompact:'Modo compacto',
    historySearchPlaceholder:'Filtrar historial…', historyNoResults:'Sin resultados',
    scCompact:'Alternar compacto', sub:'PDF · EPUB · MOBI · 1.10v',
  },
  fr:{
    sub:'PDF · EPUB · MOBI · 1.10v', donate:'Donner ♥',
    tabSearch:'Chercher', tabHistory:'Historique', tabFavorites:'Favoris', tabSettings:'Réglages',
    placeholder:'Rechercher livres, fichiers...', searchBtn:'Chercher',
    filterAll:'Tout', worksOn:'Compatible avec',
    historyTitle:'Recherches récentes', clearAll:'Tout effacer', historyEmpty:'Aucune recherche', welcomeTitle:'Bienvenue sur Toilet Finder', welcomeSub:'Cherchez un livre ou document ci-dessous. Quelques idées pour commencer:', favsWelcomeTitle:'Aucun favori', favsWelcomeSub:'Ajoutez une ★ à une recherche pour la sauvegarder ici.', queryPreviewLabel:'Recherche:',
    favsTitle:'Favoris enregistrés', favsEmpty:'Aucun favori',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Apparence', labelDark:'Mode sombre', labelAccent:"Couleur d'accent (Mode Clair uniquement)",
    labelLang:"Langue de l'interface", labelEngine:'Moteur de recherche',
    labelDev:'Mode développeur', labelDevToggle:'Activer le mode développeur',
    labelCustom:'URL personnalisée', saveBtn:'Enregistrer', savedMsg:'✓ Enregistré',
    labelShortcuts:'Raccourcis clavier',
    scSearch:'Lancer', scFocus:'Accès recherche', scTabs:"Changer d'onglets",
    scFilters:'Changer filtres', scClose:'Fermer popup', scCopy:'Copier requête',
    confirmTitle:"Effacer l'historique?", confirmBody:"Tout l'historique sera supprimé.",
    cancel:'Annuler', confirmOk:'Effacer',
    previewTitle:'Aperçu', previewOpen:'Ouvrir dans le navigateur',
    previewLoading:'Chargement...', previewError:'Aperçu non disponible.',
    close:'Fermer',
    flashTab:(n)=>`Onglet ${n}`, flashFilter:(f)=>`Filtre: ${f}`, flashCopy:'Requête copiée !',
    flashFav:'Ajouté aux favoris ★', flashUnfav:'Retiré des favoris',
    libsLabel:'Recherche directe',
    exportBtn:'↓ Exporter JSON', importBtn:'Importer', labelDataIO:'Données historique', importPlaceholder:'Collez le JSON…',
    importSuccess:(n)=>`${n} entrées importées`, importError:'JSON invalide',
    statsChip:(n)=>`${n} recherche${n===1?'':'s'}`,
    isbnDetected:'ISBN détecté',
    isbnPill:(isbn)=>`ISBN ${isbn}`,
    isbnSearchAnnas:"Anna's", isbnSearchLibgen:'LibGen', isbnSearchOpenlib:'OpenLib',
    authorLabel:'Rechercher par auteur', authorLabelShort:'Par', authorPlaceholder:"Nom de l'auteur…",
    scAuthor:'Accès auteur', badgeTitle:(n)=>`${n} recherches`,
    devWarning:"Ces liens peuvent ne pas fonctionner correctement. Des sites comme Z-Library changent souvent de domaine et peuvent être bloqués dans votre région.",
    ctxUse:'Utiliser', ctxBanner:(q)=>`Sélectionné: ${q}`,
    labelShowAuthor:"Afficher le champ d'auteur", labelShowStats:'Afficher le compteur', labelFocusMode:'Mode focus', labelDevTimestamps:'Horodatages exacts', labelDevQueryPreview:'Aperçu query', copyJsonBtn:'{ } Copier en JSON', authorChipAccept:'Déplacer vers auteur', authorChipLabel:(a)=>`Auteur détecté: "${a}"`, favLabelRead:'📖 Lecture', favLabelDone:'✅ Téléchargé', favLabelPending:'🔍 En attente', favSortAlpha:'A→Z', favSortDate:'Par date', lastSearchLabel:'Rechercher encore:',
    labelAutoDark:'Suivre le thème système', labelCompact:'Mode compact',
    historySearchPlaceholder:'Filtrer…', historyNoResults:'Aucun résultat',
    scCompact:'Basculer compact', sub:'PDF · EPUB · MOBI · 1.10v',
  },
  de:{
    sub:'PDF · EPUB · MOBI · 1.10v', donate:'Spenden ♥',
    tabSearch:'Suchen', tabHistory:'Verlauf', tabFavorites:'Favoriten', tabSettings:'Einstellungen',
    placeholder:'Bücher, Dateien suchen...', searchBtn:'Suchen',
    filterAll:'Alle', worksOn:'Funktioniert mit',
    historyTitle:'Letzte Suchen', clearAll:'Alle löschen', historyEmpty:'Keine Suchen', welcomeTitle:'Willkommen bei Toilet Finder', welcomeSub:'Suche unten nach Büchern oder Dokumenten. Ideen zum Starten:', favsWelcomeTitle:'Keine Favoriten', favsWelcomeSub:'Markiere eine Suche mit ★ um sie hier zu speichern.', queryPreviewLabel:'Suche:',
    favsTitle:'Gespeicherte Favoriten', favsEmpty:'Keine Favoriten',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Erscheinungsbild', labelDark:'Dunkelmodus', labelAccent:'Akzentfarbe (nur Hellmodus)',
    labelLang:'Oberflächensprache', labelEngine:'Suchmaschine',
    labelDev:'Entwicklermodus', labelDevToggle:'Entwicklermodus aktivieren',
    labelCustom:'Benutzerdefinierte URL', saveBtn:'Speichern', savedMsg:'✓ Gespeichert',
    labelShortcuts:'Tastenkürzel',
    scSearch:'Suche starten', scFocus:'Fokussieren', scTabs:'Tabs wechseln',
    scFilters:'Filter wechseln', scClose:'Popup schließen', scCopy:'Suche kopieren',
    confirmTitle:'Verlauf löschen?', confirmBody:'Der gesamte Verlauf wird gelöscht.',
    cancel:'Abbrechen', confirmOk:'Löschen',
    previewTitle:'Vorschau', previewOpen:'Im Browser öffnen',
    previewLoading:'Lädt...', previewError:'Vorschau nicht verfügbar.',
    close:'Schließen',
    flashTab:(n)=>`Tab ${n}`, flashFilter:(f)=>`Filter: ${f}`, flashCopy:'Kopiert!',
    flashFav:'Zu Favoriten hinzugefügt ★', flashUnfav:'Aus Favoriten entfernt',
    libsLabel:'Direkte Suche',
    exportBtn:'↓ Exportieren JSON', importBtn:'Importieren', labelDataIO:'Verlaufsdaten', importPlaceholder:'JSON einfügen…',
    importSuccess:(n)=>`${n} Einträge importiert`, importError:'Ungültiges JSON',
    statsChip:(n)=>`${n} Suche${n===1?'':'n'}`,
    isbnDetected:'ISBN erkannt',
    isbnPill:(isbn)=>`ISBN ${isbn}`,
    isbnSearchAnnas:"Anna's", isbnSearchLibgen:'LibGen', isbnSearchOpenlib:'OpenLib',
    authorLabel:'Nach Autor suchen', authorLabelShort:'Von', authorPlaceholder:'Autorenname…',
    scAuthor:'Autor fokussieren', badgeTitle:(n)=>`${n} Suchen`,
    devWarning:"Diese Links funktionieren möglicherweise nicht korrekt. Seiten wie Z-Library wechseln häufig ihre Domain und könnten in Ihrer Region gesperrt sein.",
    ctxUse:'Verwenden', ctxBanner:(q)=>`Ausgewählt: ${q}`,
    labelShowAuthor:'Autorenfeld anzeigen', labelShowStats:'Suchzähler anzeigen', labelFocusMode:'Fokusmodus', labelDevTimestamps:'Genaue Zeitstempel', labelDevQueryPreview:'Query-Vorschau', copyJsonBtn:'{ } Als JSON kopieren', authorChipAccept:'Zu Autor verschieben', authorChipLabel:(a)=>`Autor erkannt: "${a}"`, favLabelRead:'📖 Lesen', favLabelDone:'✅ Heruntergeladen', favLabelPending:'🔍 Ausstehend', favSortAlpha:'A→Z', favSortDate:'Nach Datum', lastSearchLabel:'Erneut suchen:',
    labelAutoDark:'Systemdesign folgen', labelCompact:'Kompaktmodus',
    historySearchPlaceholder:'Verlauf filtern…', historyNoResults:'Keine Treffer',
    scCompact:'Kompakt umschalten', sub:'PDF · EPUB · MOBI · 1.10v',
  },
  pt:{
    sub:'PDF · EPUB · MOBI · 1.10v', donate:'Doar ♥',
    tabSearch:'Buscar', tabHistory:'Histórico', tabFavorites:'Favoritos', tabSettings:'Configurações',
    placeholder:'Buscar livros, arquivos...', searchBtn:'Buscar',
    filterAll:'Tudo', worksOn:'Funciona com',
    historyTitle:'Buscas recentes', clearAll:'Limpar tudo', historyEmpty:'Nenhuma busca ainda', welcomeTitle:'Bem-vindo ao Toilet Finder', welcomeSub:'Pesquise livros ou ficheiros abaixo. Algumas ideias:', favsWelcomeTitle:'Sem favoritos', favsWelcomeSub:'Prima ★ em qualquer pesquisa para guardar aqui.', queryPreviewLabel:'Pesquisa:',
    favsTitle:'Favoritos salvos', favsEmpty:'Nenhum favorito ainda',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Aparência', labelDark:'Modo escuro', labelAccent:'Cor de destaque (Modo Claro apenas)',
    labelLang:'Idioma da interface', labelEngine:'Motor de busca',
    labelDev:'Modo desenvolvedor', labelDevToggle:'Ativar modo desenvolvedor',
    labelCustom:'URL personalizada', saveBtn:'Salvar', savedMsg:'✓ Salvo',
    labelShortcuts:'Atalhos de teclado',
    scSearch:'Buscar', scFocus:'Focar busca', scTabs:'Trocar abas',
    scFilters:'Ciclar filtros', scClose:'Fechar popup', scCopy:'Copiar busca',
    confirmTitle:'Limpar histórico?', confirmBody:'Todo o histórico será excluído.',
    cancel:'Cancelar', confirmOk:'Limpar',
    previewTitle:'Pré-visualização', previewOpen:'Abrir no navegador',
    previewLoading:'Carregando...', previewError:'Pré-visualização indisponível.',
    close:'Fechar',
    flashTab:(n)=>`Aba ${n}`, flashFilter:(f)=>`Filtro: ${f}`, flashCopy:'Copiado!',
    flashFav:'Adicionado aos favoritos ★', flashUnfav:'Removido dos favoritos',
    libsLabel:'Busca direta',
    exportBtn:'↓ Exportar JSON', importBtn:'Importar', labelDataIO:'Datos del historial', importPlaceholder:'Cole o JSON para importar…',
    importSuccess:(n)=>`${n} entradas importadas`, importError:'JSON inválido',
    statsChip:(n)=>`${n} busca${n===1?'':'s'}`,
    isbnDetected:'ISBN detectado',
    isbnPill:(isbn)=>`ISBN ${isbn}`,
    isbnSearchAnnas:"Anna's", isbnSearchLibgen:'LibGen', isbnSearchOpenlib:'OpenLib',
    authorLabel:'Pesquisar por autor', authorLabelShort:'Por', authorPlaceholder:'Nome do autor…',
    scAuthor:'Focar autor', badgeTitle:(n)=>`${n} buscas`,
    devWarning:"Estes links podem não funcionar corretamente. Sites como o Z-Library mudam de domínio com frequência e podem estar bloqueados na sua região.",
    ctxUse:'Usar', ctxBanner:(q)=>`Selecionado: ${q}`,
    labelShowAuthor:'Mostrar campo de autor', labelShowStats:'Mostrar contador', labelFocusMode:'Modo foco', labelDevTimestamps:'Timestamps exatos', labelDevQueryPreview:'Pré-visualização', copyJsonBtn:'{ } Copiar como JSON', authorChipAccept:'Mover para autor', authorChipLabel:(a)=>`Autor detetado: "${a}"`, favLabelRead:'📖 Lendo', favLabelDone:'✅ Baixado', favLabelPending:'🔍 Pendente', favSortAlpha:'A→Z', favSortDate:'Por data', lastSearchLabel:'Pesquisar novamente:',
    labelAutoDark:'Seguir tema do sistema', labelCompact:'Modo compacto',
    historySearchPlaceholder:'Filtrar histórico…', historyNoResults:'Sem resultados',
    scCompact:'Alternar compacto', sub:'PDF · EPUB · MOBI · 1.10v',
  },
  it:{
    sub:'PDF · EPUB · MOBI · 1.10v', donate:'Dona ♥',
    tabSearch:'Cerca', tabHistory:'Cronologia', tabFavorites:'Preferiti', tabSettings:'Impostazioni',
    placeholder:'Cerca libri, file...', searchBtn:'Cerca',
    filterAll:'Tutto', worksOn:'Funziona con',
    historyTitle:'Ricerche recenti', clearAll:'Cancella tutto', historyEmpty:'Nessuna ricerca', welcomeTitle:'Benvenuto su Toilet Finder', welcomeSub:'Cerca un libro o documento qui sotto. Alcune idee per iniziare:', favsWelcomeTitle:'Nessun preferito', favsWelcomeSub:'Aggiungi ★ a una ricerca per salvarla qui.', queryPreviewLabel:'Ricerca:',
    favsTitle:'Preferiti salvati', favsEmpty:'Nessun preferito',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Aspetto', labelDark:'Modalità scura', labelAccent:'Colore accento (solo Modalità Chiara)',
    labelLang:"Lingua dell'interfaccia", labelEngine:'Motore di ricerca',
    labelDev:'Modalità sviluppatore', labelDevToggle:'Attiva modalità sviluppatore',
    labelCustom:'URL personalizzato', saveBtn:'Salva', savedMsg:'✓ Salvato',
    labelShortcuts:'Scorciatoie tastiera',
    scSearch:'Cerca', scFocus:'Accedi ricerca', scTabs:'Cambia schede',
    scFilters:'Cicla filtri', scClose:'Chiudi popup', scCopy:'Copia ricerca',
    confirmTitle:'Cancellare la cronologia?', confirmBody:'Tutta la cronologia verrà eliminata.',
    cancel:'Annulla', confirmOk:'Cancella',
    previewTitle:'Anteprima', previewOpen:'Apri nel browser',
    previewLoading:'Caricamento...', previewError:'Anteprima non disponibile.',
    close:'Chiudi',
    flashTab:(n)=>`Scheda ${n}`, flashFilter:(f)=>`Filtro: ${f}`, flashCopy:'Copiato!',
    flashFav:'Aggiunto ai preferiti ★', flashUnfav:'Rimosso dai preferiti',
    libsLabel:'Ricerca diretta',
    exportBtn:'↓ Esporta JSON', importBtn:'Importa', labelDataIO:'Dati cronologia', importPlaceholder:'Incolla JSON…',
    importSuccess:(n)=>`${n} voci importate`, importError:'JSON non valido',
    statsChip:(n)=>`${n} ricer${n===1?'ca':'che'}`,
    isbnDetected:'ISBN rilevato',
    isbnPill:(isbn)=>`ISBN ${isbn}`,
    isbnSearchAnnas:"Anna's", isbnSearchLibgen:'LibGen', isbnSearchOpenlib:'OpenLib',
    authorLabel:'Cerca per autore', authorLabelShort:'Di', authorPlaceholder:"Nome dell'autore…",
    scAuthor:'Accedi autore', badgeTitle:(n)=>`${n} ricerche`,
    devWarning:"Questi link potrebbero non funzionare correttamente. Siti come Z-Library cambiano dominio frequentemente e potrebbero essere bloccati nella tua regione.",
    ctxUse:'Usa', ctxBanner:(q)=>`Selezionato: ${q}`,
    labelShowAuthor:"Mostra campo autore", labelShowStats:'Mostra contatore', labelFocusMode:'Modalità focus', labelDevTimestamps:'Timestamp esatti', labelDevQueryPreview:'Anteprima query', copyJsonBtn:'{ } Copia come JSON', authorChipAccept:'Sposta ad autore', authorChipLabel:(a)=>`Autore rilevato: "${a}"`, favLabelRead:'📖 Lettura', favLabelDone:'✅ Scaricato', favLabelPending:'🔍 In attesa', favSortAlpha:'A→Z', favSortDate:'Per data', lastSearchLabel:'Cerca ancora:',
    labelAutoDark:'Segui tema sistema', labelCompact:'Modalità compatta',
    historySearchPlaceholder:'Filtra cronologia…', historyNoResults:'Nessun risultato',
    scCompact:'Attiva/disattiva compatto', sub:'PDF · EPUB · MOBI · 1.10v',
  },
  zh:{
    sub:'PDF · EPUB · MOBI · 1.10v', donate:'捐赠 ♥',
    tabSearch:'搜索', tabHistory:'历史', tabFavorites:'收藏', tabSettings:'设置',
    placeholder:'搜索书籍、文件...', searchBtn:'搜索',
    filterAll:'全部', worksOn:'适用于',
    historyTitle:'最近搜索', clearAll:'清除全部', historyEmpty:'暂无搜索记录', welcomeTitle:'欢迎使用 Toilet Finder', welcomeSub:'在下方搜索书籍。一些建议：', favsWelcomeTitle:'暂无收藏', favsWelcomeSub:'点击 ★ 收藏搜索记录。', queryPreviewLabel:'搜索:',
    favsTitle:'已收藏', favsEmpty:'暂无收藏',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'外观', labelDark:'深色模式', labelAccent:'强调色',
    labelLang:'界面语言', labelEngine:'搜索引擎',
    labelDev:'开发者模式', labelDevToggle:'启用开发者模式',
    labelCustom:'自定义网址', saveBtn:'保存', savedMsg:'✓ 已保存',
    labelShortcuts:'键盘快捷键',
    scSearch:'执行搜索', scFocus:'聚焦搜索', scTabs:'切换标签',
    scFilters:'切换过滤器', scClose:'关闭弹窗', scCopy:'复制查询',
    confirmTitle:'清除历史?', confirmBody:'所有搜索历史将被永久删除。',
    cancel:'取消', confirmOk:'清除',
    previewTitle:'预览', previewOpen:'在浏览器中打开',
    previewLoading:'加载中...', previewError:'预览不可用。',
    close:'关闭',
    flashTab:(n)=>`标签 ${n}`, flashFilter:(f)=>`过滤: ${f}`, flashCopy:'已复制！',
    flashFav:'已添加到收藏 ★', flashUnfav:'已取消收藏',
    libsLabel:'直接搜索',
    exportBtn:'↓ 导出 JSON', importBtn:'导入', labelDataIO:'历史数据', importPlaceholder:'粘贴 JSON…',
    importSuccess:(n)=>`已导入 ${n} 条`, importError:'JSON 无效',
    statsChip:(n)=>`${n} 次搜索`,
    isbnDetected:'检测到 ISBN',
    isbnPill:(isbn)=>`ISBN ${isbn}`,
    isbnSearchAnnas:"安娜档案", isbnSearchLibgen:'LibGen', isbnSearchOpenlib:'开放图书馆',
    authorLabel:'按作者搜索', authorLabelShort:'作者', authorPlaceholder:'作者姓名…',
    scAuthor:'聚焦作者', badgeTitle:(n)=>`${n}次搜索`,
    devWarning:"这些链接可能无法正常工作。Z-Library 等网站经常更换域名，在您所在的地区也可能被屏蔽。",
    ctxUse:'使用', ctxBanner:(q)=>`已选: ${q}`,
    labelShowAuthor:'显示作者字段', labelShowStats:'显示搜索计数', labelFocusMode:'专注模式', labelDevTimestamps:'精确时间戳', labelDevQueryPreview:'查询预览', copyJsonBtn:'{ } 复制为 JSON', authorChipAccept:'移至作者', authorChipLabel:(a)=>`检测到作者: "${a}"`, favLabelRead:'📖 阅读中', favLabelDone:'✅ 已下载', favLabelPending:'🔍 待办', favSortAlpha:'A→Z', favSortDate:'按日期', lastSearchLabel:'再次搜索:',
    labelAutoDark:'跟随系统主题', labelCompact:'紧凑模式',
    historySearchPlaceholder:'筛选历史…', historyNoResults:'无匹配',
    scCompact:'切换紧凑', sub:'PDF · EPUB · MOBI · 1.10v',
  },
  ja:{
    sub:'PDF · EPUB · MOBI · 1.10v', donate:'寄付 ♥',
    tabSearch:'検索', tabHistory:'履歴', tabFavorites:'お気に入り', tabSettings:'設定',
    placeholder:'書籍やファイルを検索...', searchBtn:'検索',
    filterAll:'すべて', worksOn:'対応ブラウザ',
    historyTitle:'最近の検索', clearAll:'すべて削除', historyEmpty:'検索履歴なし', welcomeTitle:'Toilet Finder へようこそ', welcomeSub:'本やファイルを検索してみましょう：', favsWelcomeTitle:'お気に入りなし', favsWelcomeSub:'★ で検索を保存できます。', queryPreviewLabel:'検索:',
    favsTitle:'お気に入り', favsEmpty:'お気に入りなし',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'外観', labelDark:'ダークモード', labelAccent:'アクセントカラー',
    labelLang:'表示言語', labelEngine:'検索エンジン',
    labelDev:'開発者モード', labelDevToggle:'開発者モードを有効にする',
    labelCustom:'カスタムURL', saveBtn:'保存', savedMsg:'✓ 保存済み',
    labelShortcuts:'キーボードショートカット',
    scSearch:'検索実行', scFocus:'検索にフォーカス', scTabs:'タブ切替',
    scFilters:'フィルター切替', scClose:'ポップアップを閉じる', scCopy:'クエリをコピー',
    confirmTitle:'履歴を削除?', confirmBody:'すべての検索履歴が永久に削除されます。',
    cancel:'キャンセル', confirmOk:'削除',
    previewTitle:'プレビュー', previewOpen:'ブラウザで開く',
    previewLoading:'読み込み中...', previewError:'プレビュー利用不可。',
    close:'閉じる',
    flashTab:(n)=>`タブ ${n}`, flashFilter:(f)=>`フィルター: ${f}`, flashCopy:'コピーしました！',
    flashFav:'お気に入りに追加 ★', flashUnfav:'お気に入りから削除',
    libsLabel:'直接検索',
    exportBtn:'↓ エクスポート JSON', importBtn:'インポート', labelDataIO:'履歴データ', importPlaceholder:'JSONを貼り付け…',
    importSuccess:(n)=>`${n}件インポート完了`, importError:'JSONが無効です',
    statsChip:(n)=>`${n}回検索`,
    isbnDetected:'ISBNを検出',
    isbnPill:(isbn)=>`ISBN ${isbn}`,
    isbnSearchAnnas:"Anna's", isbnSearchLibgen:'LibGen', isbnSearchOpenlib:'OpenLib',
    authorLabel:'著者で検索', authorLabelShort:'著者', authorPlaceholder:'著者名…',
    scAuthor:'著者にフォーカス', badgeTitle:(n)=>`${n}回検索`,
    devWarning:"これらのリンクは正しく動作しない場合があります。Z-Libraryなどのサイトはドメインを頻繁に変更し、お住まいの地域でブロックされている可能性があります。",
    ctxUse:'使用', ctxBanner:(q)=>`選択済み: ${q}`,
    labelShowAuthor:'著者フィールドを表示', labelShowStats:'検索カウンターを表示', labelFocusMode:'フォーカスモード', labelDevTimestamps:'正確なタイムスタンプ', labelDevQueryPreview:'クエリプレビュー', copyJsonBtn:'{ } JSON でコピー', authorChipAccept:'著者に移動', authorChipLabel:(a)=>`著者を検出: "${a}"`, favLabelRead:'📖 読書中', favLabelDone:'✅ ダウンロード済', favLabelPending:'🔍 保留中', favSortAlpha:'A→Z', favSortDate:'日付順', lastSearchLabel:'もう一度検索:',
    labelAutoDark:'システムテーマに従う', labelCompact:'コンパクトモード',
    historySearchPlaceholder:'履歴を絞り込む…', historyNoResults:'一致なし',
    scCompact:'コンパクト切替', sub:'PDF · EPUB · MOBI · 1.10v',
  },
  ru:{
    sub:'PDF · EPUB · MOBI · 1.10v', donate:'Поддержать ♥',
    tabSearch:'Поиск', tabHistory:'История', tabFavorites:'Избранное', tabSettings:'Настройки',
    placeholder:'Искать книги, файлы...', searchBtn:'Найти',
    filterAll:'Все', worksOn:'Работает в',
    historyTitle:'Недавние поиски', clearAll:'Очистить всё', historyEmpty:'Нет поисков', welcomeTitle:'Добро пожаловать в Toilet Finder', welcomeSub:'Ищите книги и документы ниже. Несколько идей для начала:', favsWelcomeTitle:'Нет избранных', favsWelcomeSub:'Нажмите ★ на любом поиске, чтобы сохранить его здесь.', queryPreviewLabel:'Поиск:',
    favsTitle:'Сохранённое', favsEmpty:'Нет избранного',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Внешний вид', labelDark:'Тёмный режим', labelAccent:'Цвет акцента (только светлый режим)',
    labelLang:'Язык интерфейса', labelEngine:'Поисковик',
    labelDev:'Режим разработчика', labelDevToggle:'Включить режим разработчика',
    labelCustom:'Свой URL', saveBtn:'Сохранить', savedMsg:'✓ Сохранено',
    labelShortcuts:'Горячие клавиши',
    scSearch:'Выполнить поиск', scFocus:'Фокус поиска', scTabs:'Переключить вкладки',
    scFilters:'Переключить фильтры', scClose:'Закрыть popup', scCopy:'Скопировать запрос',
    confirmTitle:'Очистить историю?', confirmBody:'Весь поиск будет удалён навсегда.',
    cancel:'Отмена', confirmOk:'Очистить',
    previewTitle:'Предпросмотр', previewOpen:'Открыть в браузере',
    previewLoading:'Загрузка...', previewError:'Предпросмотр недоступен.',
    close:'Закрыть',
    flashTab:(n)=>`Вкладка ${n}`, flashFilter:(f)=>`Фильтр: ${f}`, flashCopy:'Скопировано!',
    flashFav:'Добавлено в избранное ★', flashUnfav:'Удалено из избранного',
    libsLabel:'Прямой поиск',
    exportBtn:'↓ Экспорт JSON', importBtn:'Импорт', labelDataIO:'Данные истории', importPlaceholder:'Вставьте JSON…',
    importSuccess:(n)=>`Импортировано ${n} записей`, importError:'Неверный JSON',
    statsChip:(n)=>`${n} поиск${n===1?'':n<5?'а':'ов'}`,
    isbnDetected:'Обнаружен ISBN',
    isbnPill:(isbn)=>`ISBN ${isbn}`,
    isbnSearchAnnas:"Anna's", isbnSearchLibgen:'LibGen', isbnSearchOpenlib:'OpenLib',
    authorLabel:'Искать по автору', authorLabelShort:'Автор', authorPlaceholder:'Имя автора…',
    scAuthor:'Фокус на автора', badgeTitle:(n)=>`${n} поисков`,
    devWarning:"Эти ссылки могут работать некорректно. Такие сайты, как Z-Library, часто меняют домены и могут быть заблокированы в вашем регионе.",
    ctxUse:'Использовать', ctxBanner:(q)=>`Выбрано: ${q}`,
    labelShowAuthor:'Показать поле автора', labelShowStats:'Показать счётчик', labelFocusMode:'Режим фокуса', labelDevTimestamps:'Точные временные метки', labelDevQueryPreview:'Предпросмотр запроса', copyJsonBtn:'{ } Копировать как JSON', authorChipAccept:'Перенести к автору', authorChipLabel:(a)=>`Автор обнаружен: "${a}"`, favLabelRead:'📖 Читаю', favLabelDone:'✅ Скачано', favLabelPending:'🔍 Ожидание', favSortAlpha:'A→Z', favSortDate:'По дате', lastSearchLabel:'Искать снова:',
    labelAutoDark:'Следовать теме системы', labelCompact:'Компактный режим',
    historySearchPlaceholder:'Фильтр истории…', historyNoResults:'Нет совпадений',
    scCompact:'Компактный режим', sub:'PDF · EPUB · MOBI · 1.10v',
  },
};

// ── Library direct search URLs ──
const LIBS = {
  zlibrary:    q=>`https://z-library.sk/s/${encodeURIComponent(q)}`,
  annas:       q=>`https://annas-archive.org/search?q=${encodeURIComponent(q)}`,
  libgen:      q=>`https://libgen.is/search.php?req=${encodeURIComponent(q)}&res=25&view=simple`,
  openlibrary: q=>`https://openlibrary.org/search?q=${encodeURIComponent(q)}`,
};

// ISBN-specific search URLs (use dedicated ISBN lookup)
const ISBN_LIBS = {
  annas:       isbn=>`https://annas-archive.org/search?q=${encodeURIComponent(isbn)}`,
  libgen:      isbn=>`https://libgen.is/search.php?req=${encodeURIComponent(isbn)}&column=identifier`,
  openlibrary: isbn=>`https://openlibrary.org/isbn/${encodeURIComponent(isbn)}`,
};

const ENGINES = {
  google:     q=>`https://www.google.com/search?q=${q}`,
  bing:       q=>`https://www.bing.com/search?q=${q}`,
  duckduckgo: q=>`https://duckduckgo.com/?q=${q}`,
  brave:      q=>`https://search.brave.com/search?q=${q}`,
};

// ISBN detection regex (ISBN-10 or ISBN-13)
const ISBN_RE = /(?:isbn[:\s-]*)?((?:97[89][- ]?)?(?:\d[- ]?){9}[\dx])/i;

// ─── state ───
let activeType   = 'all';
let activeEngine = 'google';
let activeLang   = 'en';
let customUrl    = '';
let darkMode     = false;
let devMode      = false;
let accentColor  = '#111111';
let history      = [];
let favorites    = [];
let totalSearches = 0;
let acIdx        = -1; // autocomplete selected index
let detectedIsbn = ''; // current detected ISBN
let showAuthor   = false; // dev: show author field
let showStats    = false; // dev: show search counter
let autoDark     = false; // follow system prefers-color-scheme
let compactMode  = false; // compact layout
let historyFilter = '';   // current history search filter
let focusMode    = false; // hide header/footer
let devTimestamps= false; // exact HH:MM:SS timestamps in dev
let favsSort     = 'date';// 'date' or 'alpha'
let pinnedItems  = [];    // pinned history indices (queries)

// ─── translate ───
function applyTranslations(){
  const t = T[activeLang]||T.en;
  document.querySelectorAll('[data-t]').forEach(el=>{
    const v=t[el.dataset.t];
    // skip if element has child elements (e.g. searchBtn with spinner inside)
    if(typeof v==='string' && el.children.length===0) el.textContent=v;
  });
  document.querySelectorAll('[data-t-placeholder]').forEach(el=>{
    const v=t[el.dataset.tPlaceholder];
    if(v) el.placeholder=v;
  });
  // Author labels
  const al=document.querySelector('[data-t="authorLabel"]');
  if(al && t.authorLabel) al.textContent=t.authorLabel;
  const als=document.querySelector('[data-t="authorLabelShort"]');
  if(als && t.authorLabelShort) als.textContent=t.authorLabelShort;
  const ai=document.getElementById('authorInput');
  if(ai && t.authorPlaceholder) ai.placeholder=t.authorPlaceholder;
  updateStatsChip();
  renderHistory();
  renderFavorites();
}

// ─── stats chip ───
function updateStatsChip(){
  const t=T[activeLang]||T.en;
  const chip=document.getElementById('statsChip');
  chip.textContent=t.statsChip(totalSearches);
  chip.style.display=showStats?'':'none';
}

// ─── badge disabled — no search count notifications ───
function updateBadge(){ /* intentionally empty */ }

// ─── author field always visible in normal zone ───
function applyShowAuthor(){ /* always shown in search panel */ }

// ─── apply focus mode ───
function applyFocusMode(){
  document.body.classList.toggle('focus-mode', focusMode);
  document.getElementById('focusModeToggle').classList.toggle('on', focusMode);
}

// ─── apply dev timestamps ───
function applyDevTimestamps(){
  document.getElementById('devTimestampsToggle').classList.toggle('on', devTimestamps);
}

// ─── update dev query preview ───
function updateDevQueryPreview(){
  const el=document.getElementById('devQueryPreview');
  if(!el) return;
  const q=document.getElementById('searchInput').value.trim();
  if(!q){ el.textContent=''; return; }
  const author=document.getElementById('authorInput').value.trim();
  const filter=activeType==='all'?'filetype:pdf OR filetype:epub OR filetype:mobi':`filetype:${activeType}`;
  const authorPart=author?` intitle:"${author}" OR inurl:"${author}"`:'';
  const engine=activeEngine==='custom'&&customUrl?customUrl:(ENGINES[activeEngine]||ENGINES.google)('QUERY');
  el.textContent=`${q}${authorPart} ${filter}`;
}

// ─── apply stats chip visibility (dev option) ───
function applyShowStats(){
  updateStatsChip();
  document.getElementById('showStatsToggle').classList.toggle('on', showStats);
}

// ─── compact mode ───
function applyCompact(){
  document.body.classList.toggle('compact', compactMode);
  document.getElementById('compactToggle').classList.toggle('on', compactMode);
}

// ─── auto dark (follow system) ───
let sysDarkMQ = null;
function applyAutoDark(){
  document.getElementById('autoDarkToggle').classList.toggle('on', autoDark);
  // enable/disable manual dark toggle
  document.getElementById('darkToggle').style.opacity = autoDark ? '0.4' : '';
  document.getElementById('darkToggle').style.pointerEvents = autoDark ? 'none' : '';

  if(autoDark){
    sysDarkMQ = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e) => { darkMode=e.matches; applyDark(); };
    sysDarkMQ._handler = handler;
    sysDarkMQ.addEventListener('change', handler);
    darkMode = sysDarkMQ.matches;
    applyDark();
  } else {
    if(sysDarkMQ && sysDarkMQ._handler){
      sysDarkMQ.removeEventListener('change', sysDarkMQ._handler);
      sysDarkMQ = null;
    }
  }
}


function applyAccent(color){
  accentColor=color;
  if(!darkMode){
    document.documentElement.style.setProperty('--accent', color);
    document.documentElement.style.setProperty('--border-active', color==='#111111'?'#bbb':color+'bb');
  } else {
    document.documentElement.style.removeProperty('--accent');
    document.documentElement.style.removeProperty('--border-active');
  }
  document.querySelectorAll('.cswatch').forEach(s=>s.classList.toggle('active', s.dataset.color===color));
}

// ─── load ───
browser.storage.local.get(['engine','customUrl','dark','lang','history','activeType','accent','devMode','favorites','totalSearches','lastQuery','showAuthor','showStats','autoDark','compactMode','focusMode','devTimestamps','favsSort','pinnedItems','lastTab','contextQuery','contextQueryTime']).then(data=>{
  if(data.engine)       { activeEngine=data.engine; updateEngineUI(); }
  if(data.customUrl)    { customUrl=data.customUrl; document.getElementById('customUrl').value=customUrl; }
  if(data.lang)         { activeLang=data.lang; }
  if(data.dark)         { darkMode=data.dark; applyDark(); }
  if(data.history)      { history=data.history; }
  if(data.favorites)    { favorites=data.favorites; }
  if(data.totalSearches){ totalSearches=data.totalSearches; }
  if(data.showStats)    { showStats=data.showStats; }
  if(data.autoDark)     { autoDark=data.autoDark; }
  if(data.compactMode)  { compactMode=data.compactMode; }
  if(data.focusMode)    { focusMode=data.focusMode; }
  if(data.devTimestamps){ devTimestamps=data.devTimestamps; }
  if(data.favsSort)     { favsSort=data.favsSort; }
  if(data.pinnedItems)  { pinnedItems=data.pinnedItems; }
  if(data.activeType){
    activeType=data.activeType;
    document.querySelectorAll('.fbtn').forEach(b=>b.classList.toggle('active',b.dataset.type===activeType));
  }
  if(data.accent)  { accentColor=data.accent; applyAccent(accentColor); }
  if(data.devMode) { devMode=data.devMode; applyDevMode(); }

  // Restore last query
  if(data.lastQuery){
    document.getElementById('searchInput').value=data.lastQuery;

  }

  // Context menu query (only use if fresh — within 10 seconds)
  if(data.contextQuery && data.contextQueryTime && (Date.now()-data.contextQueryTime)<10000){
    showContextBanner(data.contextQuery);
    browser.storage.local.remove(['contextQuery','contextQueryTime']);
  }

  // restore last tab
  if(data.lastTab && data.lastTab!=='search') switchTab(data.lastTab);
  updateLangUI();
  applyTranslations();
  applyShowAuthor();
  applyShowStats();
  applyCompact();
  applyAutoDark();
  applyFocusMode();
  applyDevTimestamps();
  setTimeout(updateLastSearchHint,100);
  setTimeout(updateDevQueryPreview,100);
  updateBadge();
});

// ─── dark mode ───
function applyDark(){
  document.body.classList.toggle('dark',darkMode);
  document.getElementById('darkToggle').classList.toggle('on',darkMode);
  applyAccent(accentColor);
}
document.getElementById('darkToggle').addEventListener('click',()=>{
  if(autoDark) return; // disabled when auto
  darkMode=!darkMode; applyDark();
  browser.storage.local.set({dark:darkMode});
});

document.getElementById('autoDarkToggle').addEventListener('click',()=>{
  autoDark=!autoDark;
  browser.storage.local.set({autoDark});
  applyAutoDark();
});

document.getElementById('compactToggle').addEventListener('click',()=>{
  compactMode=!compactMode;
  browser.storage.local.set({compactMode});
  applyCompact();
});

// ─── dev mode ───
function applyDevMode(){
  document.getElementById('devToggle').classList.toggle('on',devMode);
  document.getElementById('devSection').style.display=devMode?'block':'none';
}
document.getElementById('devToggle').addEventListener('click',()=>{
  devMode=!devMode; applyDevMode();
  browser.storage.local.set({devMode});
});


document.getElementById('authorClear').addEventListener('click',()=>{
  document.getElementById('authorInput').value='';
  document.getElementById('authorInput').focus();
});


document.getElementById('showStatsToggle').addEventListener('click',()=>{
  showStats=!showStats;
  browser.storage.local.set({showStats});
  applyShowStats();
});

// ─── accent swatches ───
document.querySelectorAll('.cswatch').forEach(s=>{
  s.addEventListener('click',()=>{ applyAccent(s.dataset.color); browser.storage.local.set({accent:accentColor}); });
});

// ─── tabs ───
const tabs=['search','history','favorites','settings'];
function switchTab(tabName){
  document.querySelectorAll('.ntab').forEach(b=>{ b.classList.toggle('active',b.dataset.tab===tabName); b.style.borderBottomColor=''; });
  document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id==='panel-'+tabName));
  if(tabName==='history')   renderHistory();
  if(tabName==='favorites') renderFavorites();
  closeAutocomplete();
  browser.storage.local.set({lastTab:tabName});
  if(tabName==='search') updateLastSearchHint();
}
document.querySelectorAll('.ntab').forEach(btn=>btn.addEventListener('click',()=>switchTab(btn.dataset.tab)));

// ─── engine ───
function updateEngineUI(){
  document.querySelectorAll('.ebtn').forEach(b=>b.classList.toggle('active',b.dataset.engine===activeEngine));
}
document.querySelectorAll('.ebtn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    activeEngine=btn.dataset.engine; customUrl=''; updateEngineUI();
    document.getElementById('customUrl').value='';
    browser.storage.local.set({engine:activeEngine,customUrl:''});
  });
});

// ─── language ───
function updateLangUI(){
  document.querySelectorAll('.lbtn').forEach(b=>b.classList.toggle('active',b.dataset.lang===activeLang));
}
document.querySelectorAll('.lbtn').forEach(btn=>{
  btn.addEventListener('click',()=>{ activeLang=btn.dataset.lang; updateLangUI(); applyTranslations(); browser.storage.local.set({lang:activeLang}); });
});

// ─── custom URL ───
document.getElementById('saveCustom').addEventListener('click',()=>{
  const val=document.getElementById('customUrl').value.trim();
  if(!val) return;
  customUrl=val; activeEngine='custom';
  document.querySelectorAll('.ebtn').forEach(b=>b.classList.remove('active'));
  browser.storage.local.set({engine:'custom',customUrl:val});
  const msg=document.getElementById('savedMsg');
  msg.style.display='block'; setTimeout(()=>msg.style.display='none',1500);
});

// ─── filters ───
const filterTypes=['all','pdf','epub','mobi'];
let filterIdx=0;
function setFilter(type){
  activeType=type;
  filterIdx=filterTypes.indexOf(type);
  document.querySelectorAll('.fbtn').forEach(b=>b.classList.toggle('active',b.dataset.type===type));
  browser.storage.local.set({activeType});
}
document.querySelectorAll('.fbtn').forEach(btn=>btn.addEventListener('click',()=>setFilter(btn.dataset.type)));

// ─── author toggle ───
document.getElementById('authorToggle').addEventListener('click',()=>{
  const toggle=document.getElementById('authorToggle');
  const row=document.getElementById('authorRow');
  const isOpen=toggle.classList.contains('open');
  toggle.classList.toggle('open',!isOpen);
  row.classList.toggle('open',!isOpen);
  if(!isOpen) setTimeout(()=>document.getElementById('authorInput').focus(),20);
});

// ─── DIRECT LIBRARY BUTTONS ───
document.querySelectorAll('.lib-btn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    const q=document.getElementById('searchInput').value.trim();
    const author=document.getElementById('authorInput').value.trim();
    if(!q){ showFlash('✏️'); return; }
    const searchQ=author?`${q} ${author}`:q;
    const url=LIBS[btn.dataset.lib](searchQ);
    history.unshift({query: author?`${q} (${author})`:q, type:activeType, engine:btn.dataset.lib, time:timeNow()});
    saveHistory();
    totalSearches++;
    browser.storage.local.set({totalSearches, lastQuery: q});
    updateStatsChip();
    updateBadge();
    browser.tabs.create({url});
  });
});

// ─── COPY BUTTON ───
document.getElementById('copyBtn').addEventListener('click',()=>{
  copyQuery();
});

function copyQuery(){
  const q=document.getElementById('searchInput').value.trim();
  if(!q) return;
  const t=T[activeLang]||T.en;
  const fileFilter=activeType==='all'?'filetype:pdf OR filetype:epub OR filetype:mobi':`filetype:${activeType}`;
  const fullQuery=`${q} ${fileFilter}`;
  navigator.clipboard.writeText(fullQuery).then(()=>{
    const btn=document.getElementById('copyBtn');
    btn.classList.add('copied');
    setTimeout(()=>btn.classList.remove('copied'),1200);
    showFlash(t.flashCopy);
  }).catch(()=>{});
}

// ─── AUTOCOMPLETE ───
function buildSuggestions(val){
  if(!val) return [];
  const lower=val.toLowerCase();
  const seen=new Set();
  return history
    .filter(h=>h.query.toLowerCase().startsWith(lower) && !seen.has(h.query) && seen.add(h.query))
    .slice(0,5);
}

function renderAutocomplete(suggestions){
  const dd=document.getElementById('autocompleteDropdown');
  if(!suggestions.length){ dd.classList.remove('show'); return; }
  dd.innerHTML=suggestions.map((s,i)=>`
    <div class="ac-item" data-index="${i}" data-query="${escHtml(s.query)}">
      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <span class="ac-text">${escHtml(s.query)}</span>
      <span class="ac-meta">${s.type.toUpperCase()}</span>
    </div>
  `).join('');
  dd.querySelectorAll('.ac-item').forEach(item=>{
    item.addEventListener('mousedown',e=>{
      e.preventDefault();
      document.getElementById('searchInput').value=item.dataset.query;
      closeAutocomplete();
    });
  });
  acIdx=-1;
  dd.classList.add('show');
}

function closeAutocomplete(){
  document.getElementById('autocompleteDropdown').classList.remove('show');
  acIdx=-1;
}

function navigateAutocomplete(dir){
  const dd=document.getElementById('autocompleteDropdown');
  const items=dd.querySelectorAll('.ac-item');
  if(!items.length) return;
  items.forEach(i=>i.classList.remove('selected'));
  acIdx=(acIdx+dir+items.length)%items.length;
  items[acIdx].classList.add('selected');
  document.getElementById('searchInput').value=items[acIdx].dataset.query;
}

document.getElementById('searchInput').addEventListener('input',function(){
  const val=this.value.trim();
  // ISBN detection → show pill
  const isbnMatch=val.match(ISBN_RE);
  const t=T[activeLang]||T.en;
  if(isbnMatch){
    const clean=isbnMatch[1].replace(/[- ]/g,'');
    detectedIsbn=clean;
    document.getElementById('isbnPillLabel').textContent=t.isbnPill(clean);
    document.getElementById('isbnPill').classList.add('show');
    // update tooltips with actual URLs
    document.getElementById('isbnAnnas').dataset.tooltip=`annas-archive.org/search?q=${clean}`;
    document.getElementById('isbnLibgen').dataset.tooltip=`libgen.is/search.php?req=${clean}`;
    document.getElementById('isbnOpenlib').dataset.tooltip=`openlibrary.org/isbn/${clean}`;
  } else {
    detectedIsbn='';
    document.getElementById('isbnPill').classList.remove('show');
  }
  // Autocomplete
  renderAutocomplete(buildSuggestions(val));
  // Inline preview (existing logic)
  clearTimeout(previewTimeout);
  const box=document.getElementById('previewBox');
  if(val.length<3){ box.classList.remove('show'); return; }
  previewTimeout=setTimeout(()=>{
    box.classList.add('show');
    document.getElementById('previewLoading').style.display='block';
    document.getElementById('previewInner').style.display='none';
    const apiUrl=`https://api.duckduckgo.com/?q=${encodeURIComponent(val)}&format=json&no_redirect=1&no_html=1&skip_disambig=1`;
    fetch(apiUrl).then(r=>r.json()).then(data=>{
      const snippet=data.AbstractText||data.Answer||'';
      if(!snippet){ box.classList.remove('show'); return; }
      document.getElementById('previewLoading').style.display='none';
      document.getElementById('previewInner').style.display='block';
      document.getElementById('previewTitle2').textContent=data.Heading||val;
      document.getElementById('previewUrl2').textContent=data.AbstractURL||'';
      document.getElementById('previewSnippet2').textContent=snippet;
      const openBtn=document.getElementById('previewOpenBtn');
      openBtn.onclick=()=>{ browser.tabs.create({url:data.AbstractURL||`https://www.google.com/search?q=${encodeURIComponent(val)}`}); };
    }).catch(()=>{ box.classList.remove('show'); });
  }, 600);
});


// ─── ROTATING PLACEHOLDER ───────────────────────────────────────────────────
const ROTATING_PLACEHOLDERS = [
  'The Name of the Wind','Clean Code','Dune','Sapiens',
  'The Pragmatic Programmer','1984','Atomic Habits',
  'The Lord of the Rings','Thinking, Fast and Slow',
  'Deep Work','Man\'s Search for Meaning','The Design of Everyday Things',
  'Meditations','A Brief History of Time','The Lean Startup',
];
let placeholderIdx = Math.floor(Math.random() * ROTATING_PLACEHOLDERS.length);
function rotatePlaceholder(){
  const inp = document.getElementById('searchInput');
  if(inp.value) return; // don't change if user has typed
  placeholderIdx = (placeholderIdx + 1) % ROTATING_PLACEHOLDERS.length;
  inp.placeholder = ROTATING_PLACEHOLDERS[placeholderIdx];
}
// Set initial placeholder from list
document.getElementById('searchInput').placeholder = ROTATING_PLACEHOLDERS[placeholderIdx];
// Rotate every 3s only while popup is open and field is empty
setInterval(rotatePlaceholder, 3000);

// ─── QUERY PREVIEW ──────────────────────────────────────────────────────────
// query preview removed

// ─── PASTE-TO-SEARCH ─────────────────────────────────────────────────────────
let pasteTimer = null;
document.getElementById('searchInput').addEventListener('paste', function(){
  clearTimeout(pasteTimer);
  const wasEmpty = this.value.trim() === '';
  if(wasEmpty){
    pasteTimer = setTimeout(()=>{
      if(document.getElementById('searchInput').value.trim()) doSearch();
    }, 800);
  }
});

// ─── ESC: CLEAR FIELD FIRST, THEN CLOSE ─────────────────────────────────────
document.getElementById('searchInput').addEventListener('keydown', function(e){
  if(e.key === 'Escape'){
    if(this.value){
      e.stopPropagation(); // don't bubble to window close handler
      this.value = '';
      this.dispatchEvent(new Event('input')); // update autocomplete + preview
    }
    // if already empty, fall through to existing Esc handler (close modals)
  }
}, true); // capture phase so it fires before the generic keydown

// ─── ISBN PILL BUTTONS ───
function doIsbnSearch(lib){
  if(!detectedIsbn) return;
  const url=ISBN_LIBS[lib](detectedIsbn);
  history.unshift({query:`ISBN:${detectedIsbn}`, type:activeType, engine:lib, time:timeNow()});
  saveHistory();
  totalSearches++;
  browser.storage.local.set({totalSearches, lastQuery:`ISBN:${detectedIsbn}`});
  updateStatsChip();
  updateBadge();
  browser.tabs.create({url});
}
document.getElementById('isbnAnnas').addEventListener('click',()=>doIsbnSearch('annas'));
document.getElementById('isbnLibgen').addEventListener('click',()=>doIsbnSearch('libgen'));
document.getElementById('isbnOpenlib').addEventListener('click',()=>doIsbnSearch('openlibrary'));
document.getElementById('isbnDismiss').addEventListener('click',()=>{
  document.getElementById('isbnPill').classList.remove('show');
  detectedIsbn='';
});

document.getElementById('searchInput').addEventListener('keydown',function(e){
  const dd=document.getElementById('autocompleteDropdown');
  if(!dd.classList.contains('show')) return;
  if(e.key==='ArrowDown'){ e.preventDefault(); navigateAutocomplete(1); }
  else if(e.key==='ArrowUp'){ e.preventDefault(); navigateAutocomplete(-1); }
  else if(e.key==='Escape'){ closeAutocomplete(); }
});

document.getElementById('searchInput').addEventListener('blur',()=>{
  setTimeout(closeAutocomplete,150);
});

// ─── history helpers ───
function saveHistory(){ browser.storage.local.set({history:history.slice(0,30)}); }
function saveFavorites(){ browser.storage.local.set({favorites:favorites.slice(0,50)}); }
function escHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function timeNow(){
  const d=new Date();
  if(devTimestamps) return d.toLocaleDateString([],{month:'short',day:'numeric'})+' '+d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'});
  return d.toLocaleDateString([],{month:'short',day:'numeric'})+' '+d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
}
function timeRelative(timeStr){
  // try to parse stored time string to relative format
  const now=new Date();
  // stored as "Mar 10 14:32" - hard to parse back reliably, use as-is for history display
  return timeStr;
}
function isFav(query){ return favorites.some(f=>f.query===query); }

function highlightMatch(text, filter){
  if(!filter) return escHtml(text);
  const idx=text.toLowerCase().indexOf(filter.toLowerCase());
  if(idx<0) return escHtml(text);
  return escHtml(text.slice(0,idx))+'<mark class="hmatch">'+escHtml(text.slice(idx,idx+filter.length))+'</mark>'+escHtml(text.slice(idx+filter.length));
}

const WELCOME_EXAMPLES = [
  {icon:'📚', query:'Clean Code', type:'pdf'},
  {icon:'🌌', query:'Dune Frank Herbert', type:'epub'},
  {icon:'🧠', query:'Thinking Fast and Slow', type:'pdf'},
  {icon:'🔥', query:'Atomic Habits James Clear', type:'epub'},
  {icon:'🐉', query:'The Name of the Wind', type:'mobi'},
];

function renderHistory(){
  const t=T[activeLang]||T.en;
  const list=document.getElementById('historyList');
  const filter=historyFilter.trim().toLowerCase();
  // update count badge
  const countEl=document.getElementById('historyCount');
  if(countEl) countEl.textContent=history.length||'';
  if(countEl) countEl.style.display=history.length?'':'none';
  const items=filter
    ? history.map((item,i)=>({item,i})).filter(({item})=>item.query.toLowerCase().includes(filter))
    : history.map((item,i)=>({item,i}));
  if(!items.length && !filter && !history.length){
    list.innerHTML=`<div class="welcome-wrap">
      <div class="welcome-logo"><img src="icons/logo.png" alt="logo"></div>
      <div class="welcome-title">${escHtml(t.welcomeTitle||'Welcome to Toilet Finder')}</div>
      <div class="welcome-sub">${escHtml(t.welcomeSub||'Search for any book below. Try these:')}</div>
      <div class="welcome-items">
        ${WELCOME_EXAMPLES.map(ex=>`
          <button class="welcome-item" data-query="${escHtml(ex.query)}" data-type="${ex.type}">
            <span class="welcome-item-icon">${ex.icon}</span>
            <div class="welcome-item-text">
              <div class="welcome-item-query">${escHtml(ex.query)}</div>
              <div class="welcome-item-type">${ex.type.toUpperCase()}</div>
            </div>
            <span class="welcome-item-arrow">›</span>
          </button>`).join('')}
      </div>
    </div>`;
    list.querySelectorAll('.welcome-item').forEach(el=>{
      el.addEventListener('click',()=>{
        document.getElementById('searchInput').value=el.dataset.query;
        setFilter(el.dataset.type);
        switchTab('search');
        setTimeout(()=>document.getElementById('searchInput').focus(),50);
      });
    });
    return;
  }
  if(!items.length){
    list.innerHTML=`<p class="hempty">${filter?t.historyNoResults:t.historyEmpty}</p>`;
    return;
  }
  list.innerHTML=items.map(({item,i})=>`
    <div class="hitem" data-index="${i}">
      <div class="hitem-left">
        <span class="hitem-query">${highlightMatch(item.query,filter)}</span>
        <span class="hitem-meta">${t.historyMeta(item.type.toUpperCase(),item.engine,item.time)}</span>
      </div>
      <div class="hitem-actions">
        <button class="hitem-go" data-index="${i}" title="Search now">↗</button>
        <button class="hitem-fav${isFav(item.query)?' starred':''}" data-index="${i}" title="Favorite">★</button>
        <button class="hitem-del" data-index="${i}">&times;</button>
      </div>
    </div>
  `).join('');

  list.querySelectorAll('.hitem').forEach(el=>{
    el.addEventListener('click',e=>{
      if(e.target.classList.contains('hitem-del')||e.target.classList.contains('hitem-fav')) return;
      const item=history[+el.dataset.index];
      document.getElementById('searchInput').value=item.query;
      setFilter(item.type);
      switchTab('search');
    });
  });
  list.querySelectorAll('.hitem-go').forEach(btn=>{
    btn.addEventListener('click',e=>{
      e.stopPropagation();
      const item=history[+btn.dataset.index];
      document.getElementById('searchInput').value=item.query;
      setFilter(item.type);
      switchTab('search');
      setTimeout(doSearch,50);
    });
  });
  list.querySelectorAll('.hitem-fav').forEach(btn=>{
    btn.addEventListener('click',e=>{ e.stopPropagation(); toggleFav(history[+btn.dataset.index]); });
  });
  list.querySelectorAll('.hitem-del').forEach(btn=>{
    btn.addEventListener('click',e=>{ e.stopPropagation(); history.splice(+btn.dataset.index,1); saveHistory(); renderHistory(); });
  });
}

const FAVS_WELCOME_EXAMPLES = [
  {icon:'⭐', query:'Clean Code Robert Martin', type:'pdf'},
  {icon:'⭐', query:'The Pragmatic Programmer', type:'epub'},
  {icon:'⭐', query:'Sapiens Yuval Noah Harari', type:'pdf'},
];

function renderFavorites(){
  const t=T[activeLang]||T.en;
  const list=document.getElementById('favsList');
  // update count badge
  const countEl=document.getElementById('favsCount');
  if(countEl) countEl.textContent=favorites.length||'';
  if(countEl) countEl.style.display=favorites.length?'':'none';
  if(!favorites.length){
    list.innerHTML=`<div class="welcome-wrap">
      <div class="welcome-title">${escHtml(t.favsWelcomeTitle||'No favorites yet')}</div>
      <div class="welcome-sub">${escHtml(t.favsWelcomeSub||'Star any search to save it here.')}</div>
      <div class="welcome-items">
        ${FAVS_WELCOME_EXAMPLES.map(ex=>`
          <button class="welcome-item" data-query="${escHtml(ex.query)}" data-type="${ex.type}">
            <span class="welcome-item-icon">${ex.icon}</span>
            <div class="welcome-item-text">
              <div class="welcome-item-query">${escHtml(ex.query)}</div>
              <div class="welcome-item-type">${ex.type.toUpperCase()}</div>
            </div>
            <span class="welcome-item-arrow">›</span>
          </button>`).join('')}
      </div>
      <div class="welcome-fav-hint">
        <span class="welcome-fav-hint-icon">★</span>
        <span class="welcome-fav-hint-text">${escHtml(t.favsWelcomeSub||'Star any search to save it here.')}</span>
      </div>
    </div>`;
    list.querySelectorAll('.welcome-item').forEach(el=>{
      el.addEventListener('click',()=>{
        document.getElementById('searchInput').value=el.dataset.query;
        setFilter(el.dataset.type);
        switchTab('search');
        setTimeout(()=>document.getElementById('searchInput').focus(),50);
      });
    });
    return;
  }
  const t2=T[activeLang]||T.en;
  const sorted=favsSort==='alpha'
    ? [...favorites].map((item,i)=>({item,i})).sort((a,b)=>a.item.query.localeCompare(b.item.query))
    : favorites.map((item,i)=>({item,i}));
  document.getElementById('favsSortBtn').textContent=favsSort==='alpha'?(t2.favSortAlpha||'A→Z'):(t2.favSortDate||'By date');
  const LABEL_CLASSES={read:'read',done:'done',pending:'pending'};
  const LABEL_TEXT={read:t2.favLabelRead||'📖 Reading',done:t2.favLabelDone||'✅ Downloaded',pending:t2.favLabelPending||'🔍 Pending'};
  list.innerHTML=sorted.map(({item,i})=>`
    <div class="fitem" data-index="${i}">
      <div class="fitem-left">
        <span class="fitem-query">${escHtml(item.query)}${item.label?`<span class="fitem-label ${LABEL_CLASSES[item.label]||''}">${LABEL_TEXT[item.label]||''}</span>`:''}</span>
        <span class="fitem-meta">${item.type.toUpperCase()} · ${item.engine}</span>
      </div>
      <div style="display:flex;gap:2px;align-items:center;flex-shrink:0;">
        <button class="fitem-label-btn" data-index="${i}" title="Label" style="background:none;border:none;cursor:pointer;font-size:12px;color:var(--text-dim);padding:0 2px;line-height:1;">🏷</button>
        <div class="fitem-label-picker" id="labelpicker-${i}">
          <button class="fitem-label-opt" data-label="read">${LABEL_TEXT.read}</button>
          <button class="fitem-label-opt" data-label="done">${LABEL_TEXT.done}</button>
          <button class="fitem-label-opt" data-label="pending">${LABEL_TEXT.pending}</button>
          <button class="fitem-label-opt" data-label="">— None</button>
        </div>
        <button class="fitem-del" data-index="${i}">&times;</button>
      </div>
    </div>
  `).join('');

  list.querySelectorAll('.fitem').forEach(el=>{
    el.addEventListener('click',e=>{
      if(e.target.classList.contains('fitem-del')||e.target.classList.contains('fitem-label-btn')||e.target.classList.contains('fitem-label-opt')) return;
      const item=favorites[+el.dataset.index];
      document.getElementById('searchInput').value=item.query;
      setFilter(item.type);
      switchTab('search');
    });
  });
  list.querySelectorAll('.fitem-label-btn').forEach(btn=>{
    btn.addEventListener('click',e=>{
      e.stopPropagation();
      document.querySelectorAll('.fitem-label-picker').forEach(p=>p.classList.remove('show'));
      document.getElementById('labelpicker-'+btn.dataset.index).classList.add('show');
    });
  });
  list.querySelectorAll('.fitem-label-opt').forEach(opt=>{
    opt.addEventListener('click',e=>{
      e.stopPropagation();
      const idx=+opt.closest('.fitem').dataset.index;
      favorites[idx].label=opt.dataset.label||undefined;
      if(!opt.dataset.label) delete favorites[idx].label;
      saveFavorites(); renderFavorites();
    });
  });
  document.addEventListener('click',()=>document.querySelectorAll('.fitem-label-picker').forEach(p=>p.classList.remove('show')));
  list.querySelectorAll('.fitem-del').forEach(btn=>{
    btn.addEventListener('click',e=>{ e.stopPropagation(); favorites.splice(+btn.dataset.index,1); saveFavorites(); renderFavorites(); renderHistory(); });
  });
}

function toggleFav(item){
  const t=T[activeLang]||T.en;
  const idx=favorites.findIndex(f=>f.query===item.query);
  if(idx>=0){ favorites.splice(idx,1); showFlash(t.flashUnfav); }
  else { favorites.unshift({query:item.query,type:item.type,engine:item.engine}); showFlash(t.flashFav); }
  saveFavorites(); renderHistory(); renderFavorites();
}

// ─── EXPORT / IMPORT ───
document.getElementById('exportBtn').addEventListener('click',()=>{
  const data={ history, favorites, exportedAt: new Date().toISOString(), version:'1.08' };
  const json=JSON.stringify(data, null, 2);
  const blob=new Blob([json],{type:'application/json'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url; a.download='toilet-finder-history.json'; a.click();
  URL.revokeObjectURL(url);
});

document.getElementById('importBtn').addEventListener('click',()=>{
  const t=T[activeLang]||T.en;
  const raw=document.getElementById('importInput').value.trim();
  if(!raw) return;
  try{
    const parsed=JSON.parse(raw);
    let added=0;
    if(Array.isArray(parsed)){
      // plain array
      parsed.forEach(item=>{ if(item.query){ history.unshift(item); added++; } });
    } else {
      if(parsed.history&&Array.isArray(parsed.history)){
        parsed.history.forEach(item=>{ if(item.query){ history.unshift(item); added++; } });
      }
      if(parsed.favorites&&Array.isArray(parsed.favorites)){
        parsed.favorites.forEach(item=>{ if(item.query&&!isFav(item.query)){ favorites.unshift(item); } });
        saveFavorites();
      }
    }
    saveHistory();
    renderHistory();
    document.getElementById('importInput').value='';
    showFlash(t.importSuccess(added));
  } catch(e){
    showFlash(t.importError);
  }
});

// ─── confirm modal ───
let confirmCallback=null;
function showConfirm(cb){
  confirmCallback=cb;
  document.getElementById('confirmModal').classList.add('show');
}
document.getElementById('confirmCancel').addEventListener('click',()=>{
  document.getElementById('confirmModal').classList.remove('show'); confirmCallback=null;
});
document.getElementById('confirmOk').addEventListener('click',()=>{
  document.getElementById('confirmModal').classList.remove('show');
  if(confirmCallback){ confirmCallback(); confirmCallback=null; }
});

document.getElementById('clearHistory').addEventListener('click',()=>{
  showConfirm(()=>{ history=[]; saveHistory(); renderHistory(); });
});

// ─── preview modal ───
function showPreviewModal(query,url){
  const t=T[activeLang]||T.en;
  document.getElementById('prevLoader').style.display='flex';
  document.getElementById('prevContent').classList.remove('show');
  document.getElementById('previewModal').classList.add('show');
  fetchPreview(query, url, t);
}

function fetchPreview(query, url, t){
  const apiUrl=`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_redirect=1&no_html=1&skip_disambig=1`;
  fetch(apiUrl)
    .then(r=>r.json())
    .then(data=>{
      document.getElementById('prevLoader').style.display='none';
      const content=document.getElementById('prevContent');
      content.classList.add('show');
      const title=data.Heading||query;
      const snippet=data.AbstractText||data.Answer||t.previewError;
      const site=data.AbstractURL||url||'';
      try{ document.getElementById('prevSite').textContent=site?new URL(site.startsWith('http')?site:'https://'+site).hostname:''; }catch(e){ document.getElementById('prevSite').textContent=''; }
      document.getElementById('prevPtitle').textContent=title;
      document.getElementById('prevPsnip').textContent=snippet;
      document.getElementById('prevOpenLink').href=url||`https://www.google.com/search?q=${encodeURIComponent(query)}`;
    })
    .catch(()=>{
      document.getElementById('prevLoader').style.display='none';
      document.getElementById('prevContent').classList.add('show');
      document.getElementById('prevSite').textContent='';
      document.getElementById('prevPtitle').textContent=query;
      document.getElementById('prevPsnip').textContent=t.previewError;
      document.getElementById('prevOpenLink').href=url||`https://www.google.com/search?q=${encodeURIComponent(query)}`;
    });
}

document.getElementById('previewClose').addEventListener('click',()=>{
  document.getElementById('previewModal').classList.remove('show');
});
document.querySelectorAll('.modal-overlay').forEach(ov=>{
  ov.addEventListener('click',e=>{ if(e.target===ov) ov.classList.remove('show'); });
});

// ─── inline preview timeout ref ───
let previewTimeout=null;

// ─── CONTEXT QUERY BANNER ───
function showContextBanner(query){
  const banner=document.getElementById('ctxBanner');
  document.getElementById('ctxQuery').textContent=query;
  banner.classList.add('show');
}

document.getElementById('ctxUse').addEventListener('click',()=>{
  const query=document.getElementById('ctxQuery').textContent;
  document.getElementById('searchInput').value=query;
  document.getElementById('ctxBanner').classList.remove('show');
  document.getElementById('searchInput').focus();
});
document.getElementById('ctxDismiss').addEventListener('click',()=>{
  document.getElementById('ctxBanner').classList.remove('show');
});

// Also listen for storage changes (in case background sets contextQuery while popup is open)
browser.storage.onChanged.addListener((changes)=>{
  if(changes.contextQuery && changes.contextQuery.newValue){
    const time=changes.contextQueryTime && changes.contextQueryTime.newValue || 0;
    if(Date.now()-time < 10000){
      showContextBanner(changes.contextQuery.newValue);
      browser.storage.local.remove(['contextQuery','contextQueryTime']);
    }
  }
});

// ─── search ───
// ─── STOPWORDS (remove from query before search) ─────────────────────────────
const STOPWORDS = new Set([
  'pdf','epub','mobi','ebook','e-book','download','free','book','read','online',
  'the','a','an','of','in','on','at','to','for','and','or','with',
]);
function cleanQuery(q){
  return q.split(/\s+/)
    .filter(w=>!STOPWORDS.has(w.toLowerCase().replace(/[.,!?]/g,'')))
    .join(' ').trim() || q.trim();
}

function doSearch(){
  const raw=document.getElementById('searchInput').value.trim();
  if(!raw){
    // shake animation on empty
    const inp=document.getElementById('searchInput');
    inp.classList.remove('shake');
    void inp.offsetWidth; // reflow to restart animation
    inp.classList.add('shake');
    setTimeout(()=>inp.classList.remove('shake'), 400);
    return;
  }
  const query=cleanQuery(raw);
  // update field to show cleaned query (only if changed)
  if(query!==raw) document.getElementById('searchInput').value=query;
  const author=document.getElementById('authorInput').value.trim();
  closeAutocomplete();
  document.getElementById('previewBox').classList.remove('show');
  const fileFilter=activeType==='all'?'filetype:pdf OR filetype:epub OR filetype:mobi':`filetype:${activeType}`;
  const authorPart=author?` intitle:"${author}" OR inurl:"${author}"`:'';
  const fullQuery=encodeURIComponent(`${query}${authorPart} ${fileFilter}`);
  let url;
  if(activeEngine==='custom'&&customUrl) url=customUrl+fullQuery;
  else url=(ENGINES[activeEngine]||ENGINES.google)(fullQuery);
  history.unshift({query: author?`${query} (${author})`:query, type:activeType, engine:activeEngine, time:timeNow()});
  saveHistory();
  totalSearches++;
  browser.storage.local.set({totalSearches, lastQuery: query});
  updateStatsChip();
  updateBadge();

  // spinner
  const btn=document.getElementById('searchBtn');
  btn.classList.add('searching');
  setTimeout(()=>btn.classList.remove('searching'), 600);

  browser.tabs.create({url});
}
document.getElementById('searchBtn').addEventListener('click',doSearch);

// ─── HISTORY SEARCH FILTER ───
document.getElementById('historySearch').addEventListener('input', function(){
  historyFilter = this.value;
  renderHistory();
});

// clear filter when switching away from history tab
const _origSwitchTab = switchTab;


// ─── WORD COUNTER ────────────────────────────────────────────────────────────
function updateWordCounter(){
  const val=document.getElementById('searchInput').value.trim();
  const wc=document.getElementById('wordCounter');
  if(!wc) return;
  if(!val){ wc.textContent=''; wc.className='word-counter'; return; }
  const n=val.split(/\s+/).filter(Boolean).length;
  wc.textContent=`${n}w`;
  wc.className='word-counter'+(n>=8?' over':n>=6?' warn':'');
}
document.getElementById('searchInput').addEventListener('input', updateWordCounter);


// ─── LAST SEARCH HINT ────────────────────────────────────────────────────────
function updateLastSearchHint(){
  const hint=document.getElementById('lastSearchHint');
  const hintText=document.getElementById('lastSearchHintText');
  const inp=document.getElementById('searchInput');
  if(!hint||!hintText) return;
  // show only when input is empty and we have a lastQuery
  browser.storage.local.get('lastQuery').then(data=>{
    if(data.lastQuery && !inp.value.trim()){
      const t=T[activeLang]||T.en;
      hintText.textContent=(t.lastSearchLabel||'Search again:')+' '+data.lastQuery;
      hint.classList.add('show');
      hint.onclick=()=>{
        inp.value=data.lastQuery;
        hint.classList.remove('show');
        inp.focus();
      };
    } else {
      hint.classList.remove('show');
    }
  });
}
document.getElementById('searchInput').addEventListener('input',()=>{
  const hint=document.getElementById('lastSearchHint');
  if(hint && document.getElementById('searchInput').value) hint.classList.remove('show');
  else updateLastSearchHint();
});


// ─── AUTHOR DETECTION ────────────────────────────────────────────────────────
// Heuristic: if query has 3+ words, last 1-2 words might be author name
// Look for patterns: "Title FirstName LastName" where last words are capitalized proper nouns
function detectAuthorInQuery(q){
  const words=q.trim().split(/\s+/);
  if(words.length<3) return null;
  // Last 2 words both capitalized = likely author
  const last2=words.slice(-2);
  const last1=words.slice(-1);
  if(last2.every(w=>/^[A-Z][a-z]{1,}$/.test(w)) && words.length>=4){
    return {author:last2.join(' '), title:words.slice(0,-2).join(' ')};
  }
  if(last1.every(w=>/^[A-Z][a-z]{2,}$/.test(w)) && words.length>=3 && words.slice(0,-1).some(w=>/^[A-Z]/.test(w))){
    return {author:last1[0], title:words.slice(0,-1).join(' ')};
  }
  return null;
}

let authorChipDismissed=false;
function checkAuthorDetection(){
  if(authorChipDismissed) return;
  const chip=document.getElementById('authorChip');
  if(!chip) return;
  const q=document.getElementById('searchInput').value;
  const detected=detectAuthorInQuery(q);
  const t=T[activeLang]||T.en;
  if(detected && devMode){
    document.getElementById('authorChipText').textContent=(t.authorChipLabel||((a)=>`Author detected: "${a}"`))(detected.author);
    chip.classList.add('show');
    document.getElementById('authorChipAccept').onclick=()=>{
      document.getElementById('searchInput').value=detected.title;
      if(devMode){
        document.getElementById('authorToggle').classList.add('open');
        document.getElementById('authorRow').classList.add('open');
        document.getElementById('authorInput').value=detected.author;
      }
      chip.classList.remove('show');
    };
  } else {
    chip.classList.remove('show');
  }
}
document.getElementById('searchInput').addEventListener('input',()=>{
  authorChipDismissed=false;
  checkAuthorDetection();
});
document.getElementById('authorChipDismiss').addEventListener('click',()=>{
  authorChipDismissed=true;
  document.getElementById('authorChip').classList.remove('show');
});


// ─── FAV SORT ─────────────────────────────────────────────────────────────────
document.getElementById('favsSortBtn').addEventListener('click',()=>{
  favsSort=favsSort==='date'?'alpha':'date';
  browser.storage.local.set({favsSort});
  const t=T[activeLang]||T.en;
  document.getElementById('favsSortBtn').textContent=favsSort==='alpha'?(t.favSortAlpha||'A→Z'):(t.favSortDate||'By date');
  renderFavorites();
});

// ─── FAV LABELS ──────────────────────────────────────────────────────────────
const FAV_LABELS={read:{key:'read'},done:{key:'done'},pending:{key:'pending'}};
function getFavLabel(query){ 
  return (favorites.find(f=>f.query===query)||{}).label||null;
}
function setFavLabel(query,label){
  const fav=favorites.find(f=>f.query===query);
  if(fav){ fav.label=label===fav.label?null:label; saveFavorites(); renderFavorites(); }
}


// ─── FOCUS MODE TOGGLE ───────────────────────────────────────────────────────
document.getElementById('focusModeToggle').addEventListener('click',()=>{
  focusMode=!focusMode;
  browser.storage.local.set({focusMode});
  applyFocusMode();
});

// ─── DEV TIMESTAMPS TOGGLE ───────────────────────────────────────────────────
document.getElementById('devTimestampsToggle').addEventListener('click',()=>{
  devTimestamps=!devTimestamps;
  browser.storage.local.set({devTimestamps});
  applyDevTimestamps();
  renderHistory();
});

// ─── COPY AS JSON ────────────────────────────────────────────────────────────
document.getElementById('copyJsonBtn').addEventListener('click',()=>{
  const t=T[activeLang]||T.en;
  const q=document.getElementById('searchInput').value.trim();
  const author=document.getElementById('authorInput').value.trim();
  const payload=JSON.stringify({
    query:q||null, author:author||null,
    engine:activeEngine, type:activeType,
    timestamp:new Date().toISOString(),
  },null,2);
  navigator.clipboard.writeText(payload).then(()=>showFlash('{ } Copied'));
});

// ─── DEV QUERY PREVIEW UPDATE ────────────────────────────────────────────────
document.getElementById('searchInput').addEventListener('input', updateDevQueryPreview);
document.getElementById('authorInput').addEventListener('input', updateDevQueryPreview);
document.querySelectorAll('.fbtn').forEach(btn=>{
  btn.addEventListener('click',()=>setTimeout(updateDevQueryPreview,0));
});

// ─── KEYBOARD SHORTCUTS ───
let flashTimer;
function showFlash(msg){
  const el=document.getElementById('kflash');
  el.textContent=msg; el.classList.add('show');
  clearTimeout(flashTimer);
  flashTimer=setTimeout(()=>el.classList.remove('show'),1100);
}

document.addEventListener('keydown',e=>{
  const t=T[activeLang]||T.en;
  const tag=document.activeElement.tagName;
  const inInput=tag==='INPUT'||tag==='TEXTAREA';

  if(e.key==='Enter'&&inInput){
    const dd=document.getElementById('autocompleteDropdown');
    if(dd.classList.contains('show')&&acIdx>=0){ closeAutocomplete(); return; }
    doSearch(); return;
  }

  if(e.key==='Escape'){
    if(document.getElementById('confirmModal').classList.contains('show')){ document.getElementById('confirmModal').classList.remove('show'); return; }
    if(document.getElementById('previewModal').classList.contains('show')){ document.getElementById('previewModal').classList.remove('show'); return; }
    const dd=document.getElementById('autocompleteDropdown');
    if(dd.classList.contains('show')){ closeAutocomplete(); return; }
    if(inInput){ document.activeElement.blur(); }
    return;
  }

  if(e.ctrlKey&&e.key==='k'&&!e.shiftKey){
    e.preventDefault(); switchTab('search');
    document.getElementById('searchInput').focus();
    return;
  }

  if(e.ctrlKey&&['1','2','3','4'].includes(e.key)&&!e.shiftKey&&!e.altKey){
    e.preventDefault();
    const tabName=tabs[+e.key-1];
    if(tabName){ switchTab(tabName); showFlash(t.flashTab(e.key)); }
    return;
  }

  if(e.ctrlKey&&e.shiftKey&&e.key==='F'){
    e.preventDefault();
    filterIdx=(filterIdx+1)%filterTypes.length;
    setFilter(filterTypes[filterIdx]);
    showFlash(t.flashFilter(filterTypes[filterIdx].toUpperCase()));
    return;
  }

  // Ctrl+Shift+C → copy query
  if(e.ctrlKey&&e.shiftKey&&e.key==='C'){
    e.preventDefault();
    copyQuery();
    return;
  }

  // Ctrl+Shift+A → toggle author field
  if(e.ctrlKey&&e.shiftKey&&e.key==='A'){
    e.preventDefault();
    switchTab('search');
    const toggle=document.getElementById('authorToggle');
    const row=document.getElementById('authorRow');
    const isOpen=toggle.classList.contains('open');
    toggle.classList.toggle('open',!isOpen);
    row.classList.toggle('open',!isOpen);
    if(!isOpen) setTimeout(()=>document.getElementById('authorInput').focus(),20);
    return;
  }

  // Ctrl+Shift+M → toggle compact mode
  if(e.ctrlKey&&e.shiftKey&&e.key==='M'){
    e.preventDefault();
    compactMode=!compactMode;
    browser.storage.local.set({compactMode});
    applyCompact();
    return;
  }
});
