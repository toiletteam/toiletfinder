// ═══════════════════════════════════════════════
//  TRANSLATIONS
// ═══════════════════════════════════════════════
const T = {
  en:{
    sub:'PDF · EPUB · MOBI · 1.07v', donate:'Donate ♥',
    tabSearch:'Search', tabHistory:'History', tabFavorites:'Favorites', tabSettings:'Settings',
    placeholder:'Search books, files...', searchBtn:'Search',
    filterAll:'All', worksOn:'Works on',
    historyTitle:'Recent searches', clearAll:'Clear all', historyEmpty:'No searches yet',
    favsTitle:'Saved favorites', favsEmpty:'No favorites yet',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Appearance', labelDark:'Dark mode', labelAccent:'Accent color (only available in Light Mode)',
    labelLang:'Interface language', labelEngine:'Search engine',
    labelDev:'Developer mode', labelDevToggle:'Enable developer mode',
    labelCustom:'Custom URL', saveBtn:'Save', savedMsg:'✓ Saved',
    labelShortcuts:'Keyboard shortcuts',
    scSearch:'Run search', scFocus:'Focus search', scTabs:'Switch tabs',
    scFilters:'Cycle filters', scClose:'Close popup',
    confirmTitle:'Clear history?', confirmBody:'This will permanently delete all your search history.',
    cancel:'Cancel', confirmOk:'Clear',
    previewTitle:'Top result preview', previewOpen:'Open in browser',
    previewLoading:'Loading preview...', previewError:'Preview not available.',
    close:'Close',
    flashTab:(n)=>`Tab ${n}`, flashFilter:(f)=>`Filter: ${f}`,
  },
  es:{
    sub:'PDF · EPUB · MOBI · 1.07v', donate:'Donar ♥',
    tabSearch:'Buscar', tabHistory:'Historial', tabFavorites:'Favoritos', tabSettings:'Ajustes',
    placeholder:'Buscar libros, archivos...', searchBtn:'Buscar',
    filterAll:'Todo', worksOn:'Compatible con',
    historyTitle:'Búsquedas recientes', clearAll:'Borrar todo', historyEmpty:'Sin búsquedas aún',
    favsTitle:'Favoritos guardados', favsEmpty:'Sin favoritos aún',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Apariencia', labelDark:'Modo oscuro', labelAccent:'Color de acento (solo disponible en Modo Claro)',
    labelLang:'Idioma de la interfaz', labelEngine:'Motor de búsqueda',
    labelDev:'Modo desarrollador', labelDevToggle:'Activar modo desarrollador',
    labelCustom:'URL personalizada', saveBtn:'Guardar', savedMsg:'✓ Guardado',
    labelShortcuts:'Atajos de teclado',
    scSearch:'Buscar', scFocus:'Enfocar búsqueda', scTabs:'Cambiar pestañas',
    scFilters:'Ciclar filtros', scClose:'Cerrar popup',
    confirmTitle:'¿Borrar historial?', confirmBody:'Se eliminará permanentemente todo el historial.',
    cancel:'Cancelar', confirmOk:'Borrar',
    previewTitle:'Vista previa', previewOpen:'Abrir en navegador',
    previewLoading:'Cargando vista previa...', previewError:'Vista previa no disponible.',
    close:'Cerrar',
    flashTab:(n)=>`Pestaña ${n}`, flashFilter:(f)=>`Filtro: ${f}`,
  },
  fr:{
    sub:'PDF · EPUB · MOBI · 1.07v', donate:'Donner ♥',
    tabSearch:'Chercher', tabHistory:'Historique', tabFavorites:'Favoris', tabSettings:'Réglages',
    placeholder:'Rechercher livres, fichiers...', searchBtn:'Chercher',
    filterAll:'Tout', worksOn:'Compatible avec',
    historyTitle:'Recherches récentes', clearAll:'Tout effacer', historyEmpty:'Aucune recherche',
    favsTitle:'Favoris enregistrés', favsEmpty:'Aucun favori',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Apparence', labelDark:'Mode sombre', labelAccent:"Couleur d'accent (disponible uniquement en Mode Clair)",
    labelLang:"Langue de l'interface", labelEngine:'Moteur de recherche',
    labelDev:'Mode développeur', labelDevToggle:'Activer le mode développeur',
    labelCustom:'URL personnalisée', saveBtn:'Enregistrer', savedMsg:'✓ Enregistré',
    labelShortcuts:'Raccourcis clavier',
    scSearch:'Lancer la recherche', scFocus:'Accès recherche', scTabs:'Changer d\'onglets',
    scFilters:'Changer filtres', scClose:'Fermer popup',
    confirmTitle:'Effacer l\'historique?', confirmBody:'Tout l\'historique sera supprimé.',
    cancel:'Annuler', confirmOk:'Effacer',
    previewTitle:'Aperçu', previewOpen:'Ouvrir dans le navigateur',
    previewLoading:'Chargement...', previewError:'Aperçu non disponible.',
    close:'Fermer',
    flashTab:(n)=>`Onglet ${n}`, flashFilter:(f)=>`Filtre: ${f}`,
  },
  de:{
    sub:'PDF · EPUB · MOBI · 1.07v', donate:'Spenden ♥',
    tabSearch:'Suchen', tabHistory:'Verlauf', tabFavorites:'Favoriten', tabSettings:'Einstellungen',
    placeholder:'Bücher, Dateien suchen...', searchBtn:'Suchen',
    filterAll:'Alle', worksOn:'Funktioniert mit',
    historyTitle:'Letzte Suchen', clearAll:'Alle löschen', historyEmpty:'Keine Suchen',
    favsTitle:'Gespeicherte Favoriten', favsEmpty:'Keine Favoriten',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Erscheinungsbild', labelDark:'Dunkelmodus', labelAccent:'Akzentfarbe (nur im Hellmodus verfügbar)',
    labelLang:'Oberflächensprache', labelEngine:'Suchmaschine',
    labelDev:'Entwicklermodus', labelDevToggle:'Entwicklermodus aktivieren',
    labelCustom:'Benutzerdefinierte URL', saveBtn:'Speichern', savedMsg:'✓ Gespeichert',
    labelShortcuts:'Tastenkürzel',
    scSearch:'Suche starten', scFocus:'Suche fokussieren', scTabs:'Tabs wechseln',
    scFilters:'Filter wechseln', scClose:'Popup schließen',
    confirmTitle:'Verlauf löschen?', confirmBody:'Der gesamte Suchverlauf wird gelöscht.',
    cancel:'Abbrechen', confirmOk:'Löschen',
    previewTitle:'Vorschau', previewOpen:'Im Browser öffnen',
    previewLoading:'Lädt...', previewError:'Vorschau nicht verfügbar.',
    close:'Schließen',
    flashTab:(n)=>`Tab ${n}`, flashFilter:(f)=>`Filter: ${f}`,
  },
  pt:{
    sub:'PDF · EPUB · MOBI · 1.07v', donate:'Doar ♥',
    tabSearch:'Buscar', tabHistory:'Histórico', tabFavorites:'Favoritos', tabSettings:'Configurações',
    placeholder:'Buscar livros, arquivos...', searchBtn:'Buscar',
    filterAll:'Tudo', worksOn:'Funciona com',
    historyTitle:'Buscas recentes', clearAll:'Limpar tudo', historyEmpty:'Nenhuma busca ainda',
    favsTitle:'Favoritos salvos', favsEmpty:'Nenhum favorito ainda',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Aparência', labelDark:'Modo escuro', labelAccent:'Cor de destaque (disponível apenas no Modo Claro)',
    labelLang:'Idioma da interface', labelEngine:'Motor de busca',
    labelDev:'Modo desenvolvedor', labelDevToggle:'Ativar modo desenvolvedor',
    labelCustom:'URL personalizada', saveBtn:'Salvar', savedMsg:'✓ Salvo',
    labelShortcuts:'Atalhos de teclado',
    scSearch:'Buscar', scFocus:'Focar busca', scTabs:'Trocar abas',
    scFilters:'Ciclar filtros', scClose:'Fechar popup',
    confirmTitle:'Limpar histórico?', confirmBody:'Todo o histórico será excluído permanentemente.',
    cancel:'Cancelar', confirmOk:'Limpar',
    previewTitle:'Pré-visualização', previewOpen:'Abrir no navegador',
    previewLoading:'Carregando...', previewError:'Pré-visualização indisponível.',
    close:'Fechar',
    flashTab:(n)=>`Aba ${n}`, flashFilter:(f)=>`Filtro: ${f}`,
  },
  it:{
    sub:'PDF · EPUB · MOBI · 1.07v', donate:'Dona ♥',
    tabSearch:'Cerca', tabHistory:'Cronologia', tabFavorites:'Preferiti', tabSettings:'Impostazioni',
    placeholder:'Cerca libri, file...', searchBtn:'Cerca',
    filterAll:'Tutto', worksOn:'Funziona con',
    historyTitle:'Ricerche recenti', clearAll:'Cancella tutto', historyEmpty:'Nessuna ricerca',
    favsTitle:'Preferiti salvati', favsEmpty:'Nessun preferito',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Aspetto', labelDark:'Modalità scura', labelAccent:'Colore accento (disponibile solo in Modalità Chiara)',
    labelLang:"Lingua dell'interfaccia", labelEngine:'Motore di ricerca',
    labelDev:'Modalità sviluppatore', labelDevToggle:'Attiva modalità sviluppatore',
    labelCustom:'URL personalizzato', saveBtn:'Salva', savedMsg:'✓ Salvato',
    labelShortcuts:'Scorciatoie tastiera',
    scSearch:'Cerca', scFocus:'Accedi alla ricerca', scTabs:'Cambia schede',
    scFilters:'Cicla filtri', scClose:'Chiudi popup',
    confirmTitle:'Cancellare la cronologia?', confirmBody:'Tutta la cronologia verrà eliminata.',
    cancel:'Annulla', confirmOk:'Cancella',
    previewTitle:'Anteprima', previewOpen:'Apri nel browser',
    previewLoading:'Caricamento...', previewError:'Anteprima non disponibile.',
    close:'Chiudi',
    flashTab:(n)=>`Scheda ${n}`, flashFilter:(f)=>`Filtro: ${f}`,
  },
  zh:{
    sub:'PDF · EPUB · MOBI · 1.07v', donate:'捐赠 ♥',
    tabSearch:'搜索', tabHistory:'历史', tabFavorites:'收藏', tabSettings:'设置',
    placeholder:'搜索书籍、文件...', searchBtn:'搜索',
    filterAll:'全部', worksOn:'适用于',
    historyTitle:'最近搜索', clearAll:'清除全部', historyEmpty:'暂无搜索记录',
    favsTitle:'已收藏', favsEmpty:'暂无收藏',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'外观', labelDark:'深色模式', labelAccent:'强调色',
    labelLang:'界面语言', labelEngine:'搜索引擎',
    labelDev:'开发者模式', labelDevToggle:'启用开发者模式',
    labelCustom:'自定义网址', saveBtn:'保存', savedMsg:'✓ 已保存',
    labelShortcuts:'键盘快捷键',
    scSearch:'执行搜索', scFocus:'聚焦搜索', scTabs:'切换标签',
    scFilters:'切换过滤器', scClose:'关闭弹窗',
    confirmTitle:'清除历史?', confirmBody:'所有搜索历史将被永久删除。',
    cancel:'取消', confirmOk:'清除',
    previewTitle:'预览', previewOpen:'在浏览器中打开',
    previewLoading:'加载中...', previewError:'预览不可用。',
    close:'关闭',
    flashTab:(n)=>`标签 ${n}`, flashFilter:(f)=>`过滤: ${f}`,
  },
  ja:{
    sub:'PDF · EPUB · MOBI · 1.07v', donate:'寄付 ♥',
    tabSearch:'検索', tabHistory:'履歴', tabFavorites:'お気に入り', tabSettings:'設定',
    placeholder:'書籍やファイルを検索...', searchBtn:'検索',
    filterAll:'すべて', worksOn:'対応ブラウザ',
    historyTitle:'最近の検索', clearAll:'すべて削除', historyEmpty:'検索履歴なし',
    favsTitle:'お気に入り', favsEmpty:'お気に入りなし',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'外観', labelDark:'ダークモード', labelAccent:'アクセントカラー',
    labelLang:'表示言語', labelEngine:'検索エンジン',
    labelDev:'開発者モード', labelDevToggle:'開発者モードを有効にする',
    labelCustom:'カスタムURL', saveBtn:'保存', savedMsg:'✓ 保存済み',
    labelShortcuts:'キーボードショートカット',
    scSearch:'検索実行', scFocus:'検索にフォーカス', scTabs:'タブ切替',
    scFilters:'フィルター切替', scClose:'ポップアップを閉じる',
    confirmTitle:'履歴を削除?', confirmBody:'すべての検索履歴が永久に削除されます。',
    cancel:'キャンセル', confirmOk:'削除',
    previewTitle:'プレビュー', previewOpen:'ブラウザで開く',
    previewLoading:'読み込み中...', previewError:'プレビュー利用不可。',
    close:'閉じる',
    flashTab:(n)=>`タブ ${n}`, flashFilter:(f)=>`フィルター: ${f}`,
  },
  ru:{
    sub:'PDF · EPUB · MOBI · 1.07v', donate:'Поддержать ♥',
    tabSearch:'Поиск', tabHistory:'История', tabFavorites:'Избранное', tabSettings:'Настройки',
    placeholder:'Искать книги, файлы...', searchBtn:'Найти',
    filterAll:'Все', worksOn:'Работает в',
    historyTitle:'Недавние поиски', clearAll:'Очистить всё', historyEmpty:'Нет поисков',
    favsTitle:'Сохранённое', favsEmpty:'Нет избранного',
    historyMeta:(t,e,time)=>`${t} · ${e} · ${time}`,
    labelAppearance:'Внешний вид', labelDark:'Тёмный режим', labelAccent:'Цвет акцента (доступно только в темном режиме)',
    labelLang:'Язык интерфейса', labelEngine:'Поисковик',
    labelDev:'Режим разработчика', labelDevToggle:'Включить режим разработчика',
    labelCustom:'Свой URL', saveBtn:'Сохранить', savedMsg:'✓ Сохранено',
    labelShortcuts:'Горячие клавиши',
    scSearch:'Выполнить поиск', scFocus:'Фокус поиска', scTabs:'Переключить вкладки',
    scFilters:'Переключить фильтры', scClose:'Закрыть popup',
    confirmTitle:'Очистить историю?', confirmBody:'Весь поиск будет удалён навсегда.',
    cancel:'Отмена', confirmOk:'Очистить',
    previewTitle:'Предпросмотр', previewOpen:'Открыть в браузере',
    previewLoading:'Загрузка...', previewError:'Предпросмотр недоступен.',
    close:'Закрыть',
    flashTab:(n)=>`Вкладка ${n}`, flashFilter:(f)=>`Фильтр: ${f}`,
  },
};

const ENGINES = {
  google:     q=>`https://www.google.com/search?q=${q}`,
  bing:       q=>`https://www.bing.com/search?q=${q}`,
  duckduckgo: q=>`https://duckduckgo.com/?q=${q}`,
  brave:      q=>`https://search.brave.com/search?q=${q}`,
};

// ─── state ───
let activeType   = 'all';
let activeEngine = 'google';
let activeLang   = 'en';
let customUrl    = '';
let darkMode     = false;
let devMode      = false;
let accentColor  = '#111111';
let history      = [];
let favorites    = [];

// ─── translate ───
function applyTranslations(){
  const t = T[activeLang]||T.en;
  document.querySelectorAll('[data-t]').forEach(el=>{
    const v=t[el.dataset.t];
    if(typeof v==='string') el.textContent=v;
  });
  document.querySelectorAll('[data-t-placeholder]').forEach(el=>{
    const v=t[el.dataset.tPlaceholder];
    if(v) el.placeholder=v;
  });
  renderHistory();
  renderFavorites();
}

// ─── accent (light mode only — dark uses its own neutral) ───
function applyAccent(color){
  accentColor=color;
  if(!darkMode){
    document.documentElement.style.setProperty('--accent', color);
    document.documentElement.style.setProperty('--border-active', color==='#111111'?'#bbb':color+'bb');
  } else {
    document.documentElement.style.removeProperty('--accent');
    document.documentElement.style.removeProperty('--border-active');
  }
  document.querySelectorAll('.cswatch').forEach(s=>s.classList.toggle('active', s.dataset.color===color));
  // update active tab underline
  document.querySelectorAll('.ntab.active').forEach(b=>b.style.borderBottomColor='');
}

// ─── load ───
browser.storage.local.get(['engine','customUrl','dark','lang','history','activeType','accent','devMode','favorites']).then(data=>{
  if(data.engine)     { activeEngine=data.engine; updateEngineUI(); }
  if(data.customUrl)  { customUrl=data.customUrl; document.getElementById('customUrl').value=customUrl; }
  if(data.lang)       { activeLang=data.lang; }
  if(data.dark)       { darkMode=data.dark; applyDark(); }
  if(data.history)    { history=data.history; }
  if(data.favorites)  { favorites=data.favorites; }
  if(data.activeType) {
    activeType=data.activeType;
    document.querySelectorAll('.fbtn').forEach(b=>b.classList.toggle('active',b.dataset.type===activeType));
  }
  if(data.accent)     { accentColor=data.accent; applyAccent(accentColor); }
  if(data.devMode)    { devMode=data.devMode; applyDevMode(); }
  updateLangUI();
  applyTranslations();
});

// ─── dark mode ───
function applyDark(){
  document.body.classList.toggle('dark',darkMode);
  document.getElementById('darkToggle').classList.toggle('on',darkMode);
  // re-apply accent so dark mode resets it properly
  applyAccent(accentColor);
}
document.getElementById('darkToggle').addEventListener('click',()=>{
  darkMode=!darkMode; applyDark();
  browser.storage.local.set({dark:darkMode});
});

// ─── dev mode ───
function applyDevMode(){
  document.getElementById('devToggle').classList.toggle('on',devMode);
  document.getElementById('devSection').style.display=devMode?'block':'none';
}
document.getElementById('devToggle').addEventListener('click',()=>{
  devMode=!devMode; applyDevMode();
  browser.storage.local.set({devMode});
});

// ─── accent swatches ───
document.querySelectorAll('.cswatch').forEach(s=>{
  s.addEventListener('click',()=>{ applyAccent(s.dataset.color); browser.storage.local.set({accent:accentColor}); });
});

// ─── tabs ───
const tabs=['search','history','favorites','settings'];
function switchTab(tabName){
  document.querySelectorAll('.ntab').forEach(b=>{ b.classList.toggle('active',b.dataset.tab===tabName); b.style.borderBottomColor=''; });
  document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id==='panel-'+tabName));
  if(tabName==='history') renderHistory();
  if(tabName==='favorites') renderFavorites();
}
document.querySelectorAll('.ntab').forEach(btn=>btn.addEventListener('click',()=>switchTab(btn.dataset.tab)));

// ─── engine ───
function updateEngineUI(){
  document.querySelectorAll('.ebtn').forEach(b=>b.classList.toggle('active',b.dataset.engine===activeEngine));
}
document.querySelectorAll('.ebtn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    activeEngine=btn.dataset.engine; customUrl=''; updateEngineUI();
    document.getElementById('customUrl').value='';
    browser.storage.local.set({engine:activeEngine,customUrl:''});
  });
});

// ─── language ───
function updateLangUI(){
  document.querySelectorAll('.lbtn').forEach(b=>b.classList.toggle('active',b.dataset.lang===activeLang));
}
document.querySelectorAll('.lbtn').forEach(btn=>{
  btn.addEventListener('click',()=>{ activeLang=btn.dataset.lang; updateLangUI(); applyTranslations(); browser.storage.local.set({lang:activeLang}); });
});

// ─── custom URL ───
document.getElementById('saveCustom').addEventListener('click',()=>{
  const val=document.getElementById('customUrl').value.trim();
  if(!val) return;
  customUrl=val; activeEngine='custom';
  document.querySelectorAll('.ebtn').forEach(b=>b.classList.remove('active'));
  browser.storage.local.set({engine:'custom',customUrl:val});
  const msg=document.getElementById('savedMsg');
  msg.style.display='block'; setTimeout(()=>msg.style.display='none',1500);
});

// ─── filters ───
const filterTypes=['all','pdf','epub','mobi'];
let filterIdx=0;
function setFilter(type){
  activeType=type;
  filterIdx=filterTypes.indexOf(type);
  document.querySelectorAll('.fbtn').forEach(b=>b.classList.toggle('active',b.dataset.type===type));
  browser.storage.local.set({activeType});
}
document.querySelectorAll('.fbtn').forEach(btn=>btn.addEventListener('click',()=>setFilter(btn.dataset.type)));

// ─── history helpers ───
function saveHistory(){ browser.storage.local.set({history:history.slice(0,30)}); }
function saveFavorites(){ browser.storage.local.set({favorites:favorites.slice(0,50)}); }
function escHtml(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function timeNow(){
  const d=new Date();
  return d.toLocaleDateString([],{month:'short',day:'numeric'})+' '+d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
}
function isFav(query){ return favorites.some(f=>f.query===query); }

function renderHistory(){
  const t=T[activeLang]||T.en;
  const list=document.getElementById('historyList');
  if(!history.length){ list.innerHTML=`<p class="hempty">${t.historyEmpty}</p>`; return; }
  list.innerHTML=history.map((item,i)=>`
    <div class="hitem" data-index="${i}">
      <div class="hitem-left">
        <span class="hitem-query">${escHtml(item.query)}</span>
        <span class="hitem-meta">${t.historyMeta(item.type.toUpperCase(),item.engine,item.time)}</span>
      </div>
      <div class="hitem-actions">
        <button class="hitem-fav${isFav(item.query)?' starred':''}" data-index="${i}" title="Favorite">★</button>
        <button class="hitem-del" data-index="${i}">&times;</button>
      </div>
    </div>
  `).join('');

  list.querySelectorAll('.hitem').forEach(el=>{
    el.addEventListener('click',e=>{
      if(e.target.classList.contains('hitem-del')||e.target.classList.contains('hitem-fav')) return;
      const item=history[+el.dataset.index];
      document.getElementById('searchInput').value=item.query;
      setFilter(item.type);
      switchTab('search');
    });
  });
  list.querySelectorAll('.hitem-fav').forEach(btn=>{
    btn.addEventListener('click',e=>{ e.stopPropagation(); toggleFav(history[+btn.dataset.index]); });
  });
  list.querySelectorAll('.hitem-del').forEach(btn=>{
    btn.addEventListener('click',e=>{ e.stopPropagation(); history.splice(+btn.dataset.index,1); saveHistory(); renderHistory(); });
  });
}

function renderFavorites(){
  const t=T[activeLang]||T.en;
  const list=document.getElementById('favsList');
  if(!favorites.length){ list.innerHTML=`<p class="fempty">${t.favsEmpty}</p>`; return; }
  list.innerHTML=favorites.map((item,i)=>`
    <div class="fitem" data-index="${i}">
      <div class="fitem-left">
        <span class="fitem-query">${escHtml(item.query)}</span>
        <span class="fitem-meta">${item.type.toUpperCase()} · ${item.engine}</span>
      </div>
      <button class="fitem-del" data-index="${i}">&times;</button>
    </div>
  `).join('');

  list.querySelectorAll('.fitem').forEach(el=>{
    el.addEventListener('click',e=>{
      if(e.target.classList.contains('fitem-del')) return;
      const item=favorites[+el.dataset.index];
      document.getElementById('searchInput').value=item.query;
      setFilter(item.type);
      switchTab('search');
    });
  });
  list.querySelectorAll('.fitem-del').forEach(btn=>{
    btn.addEventListener('click',e=>{ e.stopPropagation(); favorites.splice(+btn.dataset.index,1); saveFavorites(); renderFavorites(); renderHistory(); });
  });
}

function toggleFav(item){
  const idx=favorites.findIndex(f=>f.query===item.query);
  if(idx>=0) favorites.splice(idx,1);
  else favorites.unshift({query:item.query,type:item.type,engine:item.engine});
  saveFavorites(); renderHistory(); renderFavorites();
}

// ─── confirm modal ───
let confirmCallback=null;
function showConfirm(cb){
  confirmCallback=cb;
  document.getElementById('confirmModal').classList.add('show');
}
document.getElementById('confirmCancel').addEventListener('click',()=>{
  document.getElementById('confirmModal').classList.remove('show'); confirmCallback=null;
});
document.getElementById('confirmOk').addEventListener('click',()=>{
  document.getElementById('confirmModal').classList.remove('show');
  if(confirmCallback){ confirmCallback(); confirmCallback=null; }
});

document.getElementById('clearHistory').addEventListener('click',()=>{
  showConfirm(()=>{ history=[]; saveHistory(); renderHistory(); });
});

// ─── preview modal ───
let lastPreviewQuery='';
let lastPreviewUrl='';

function showPreviewModal(query,url){
  lastPreviewQuery=query; lastPreviewUrl=url;
  const t=T[activeLang]||T.en;
  document.getElementById('prevLoader').style.display='flex';
  document.getElementById('prevContent').classList.remove('show');
  document.getElementById('previewModal').classList.add('show');

  // Use DuckDuckGo instant answer API (no CORS issues for basic info)
  // Fallback: parse from Google snippet via URL
  fetchPreview(query, url, t);
}

function fetchPreview(query, url, t){
  // Use DuckDuckGo API for snippet
  const apiUrl = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_redirect=1&no_html=1&skip_disambig=1`;
  fetch(apiUrl)
    .then(r=>r.json())
    .then(data=>{
      document.getElementById('prevLoader').style.display='none';
      const content=document.getElementById('prevContent');
      content.classList.add('show');
      const title=data.Heading||query;
      const snippet=data.AbstractText||data.Answer||t.previewError;
      const site=data.AbstractURL||url||'';
      document.getElementById('prevSite').textContent=site?new URL(site.startsWith('http')?site:'https://'+site).hostname:'';
      document.getElementById('prevPtitle').textContent=title;
      document.getElementById('prevPsnip').textContent=snippet;
      const link=document.getElementById('prevOpenLink');
      link.href=url||`https://www.google.com/search?q=${encodeURIComponent(query)}`;
    })
    .catch(()=>{
      document.getElementById('prevLoader').style.display='none';
      const content=document.getElementById('prevContent');
      content.classList.add('show');
      document.getElementById('prevSite').textContent='';
      document.getElementById('prevPtitle').textContent=query;
      document.getElementById('prevPsnip').textContent=t.previewError;
      document.getElementById('prevOpenLink').href=url||`https://www.google.com/search?q=${encodeURIComponent(query)}`;
    });
}

document.getElementById('previewClose').addEventListener('click',()=>{
  document.getElementById('previewModal').classList.remove('show');
});
document.querySelectorAll('.modal-overlay').forEach(ov=>{
  ov.addEventListener('click',e=>{ if(e.target===ov) ov.classList.remove('show'); });
});

// ─── inline preview (search panel) ───
let previewTimeout=null;
document.getElementById('searchInput').addEventListener('input',function(){
  clearTimeout(previewTimeout);
  const q=this.value.trim();
  const box=document.getElementById('previewBox');
  if(q.length<3){ box.classList.remove('show'); return; }
  previewTimeout=setTimeout(()=>{
    const t=T[activeLang]||T.en;
    box.classList.add('show');
    document.getElementById('previewLoading').style.display='block';
    document.getElementById('previewInner').style.display='none';
    const apiUrl=`https://api.duckduckgo.com/?q=${encodeURIComponent(q)}&format=json&no_redirect=1&no_html=1&skip_disambig=1`;
    fetch(apiUrl).then(r=>r.json()).then(data=>{
      const snippet=data.AbstractText||data.Answer||'';
      if(!snippet){ box.classList.remove('show'); return; }
      document.getElementById('previewLoading').style.display='none';
      document.getElementById('previewInner').style.display='block';
      document.getElementById('previewTitle2').textContent=data.Heading||q;
      document.getElementById('previewUrl2').textContent=data.AbstractURL||'';
      document.getElementById('previewSnippet2').textContent=snippet;
      const openBtn=document.getElementById('previewOpenBtn');
      openBtn.onclick=()=>{ browser.tabs.create({url:data.AbstractURL||`https://www.google.com/search?q=${encodeURIComponent(q)}`}); };
    }).catch(()=>{ box.classList.remove('show'); });
  }, 600);
});

// ─── search ───
function doSearch(){
  const query=document.getElementById('searchInput').value.trim();
  if(!query) return;
  document.getElementById('previewBox').classList.remove('show');
  const fileFilter=activeType==='all'?'filetype:pdf OR filetype:epub OR filetype:mobi':`filetype:${activeType}`;
  const fullQuery=encodeURIComponent(`${query} ${fileFilter}`);
  let url;
  if(activeEngine==='custom'&&customUrl) url=customUrl+fullQuery;
  else url=(ENGINES[activeEngine]||ENGINES.google)(fullQuery);
  history.unshift({query,type:activeType,engine:activeEngine,time:timeNow()});
  saveHistory();
  browser.tabs.create({url});
}
document.getElementById('searchBtn').addEventListener('click',doSearch);

// ─── KEYBOARD SHORTCUTS (safe — no browser conflicts) ───
let flashTimer;
function showFlash(msg){
  const el=document.getElementById('kflash');
  el.textContent=msg; el.classList.add('show');
  clearTimeout(flashTimer);
  flashTimer=setTimeout(()=>el.classList.remove('show'),900);
}

document.addEventListener('keydown',e=>{
  const t=T[activeLang]||T.en;
  const tag=document.activeElement.tagName;
  const inInput=tag==='INPUT'||tag==='TEXTAREA';

  // Enter in input → search
  if(e.key==='Enter'&&inInput){ doSearch(); return; }

  // Escape → close modals or blur input
  if(e.key==='Escape'){
    if(document.getElementById('confirmModal').classList.contains('show')){ document.getElementById('confirmModal').classList.remove('show'); return; }
    if(document.getElementById('previewModal').classList.contains('show')){ document.getElementById('previewModal').classList.remove('show'); return; }
    if(inInput){ document.activeElement.blur(); }
    return;
  }

  // Ctrl+K → focus search (safe, no browser conflict in extensions)
  if(e.ctrlKey&&e.key==='k'&&!e.shiftKey){
    e.preventDefault(); switchTab('search');
    document.getElementById('searchInput').focus();
    return;
  }

  // Ctrl+1/2/3/4 → tabs (safe inside extension popup)
  if(e.ctrlKey&&['1','2','3','4'].includes(e.key)&&!e.shiftKey&&!e.altKey){
    e.preventDefault();
    const tabName=tabs[+e.key-1];
    if(tabName){ switchTab(tabName); showFlash(t.flashTab(e.key)); }
    return;
  }

  // Ctrl+Shift+F → cycle filters
  if(e.ctrlKey&&e.shiftKey&&e.key==='F'){
    e.preventDefault();
    filterIdx=(filterIdx+1)%filterTypes.length;
    setFilter(filterTypes[filterIdx]);
    showFlash(t.flashFilter(filterTypes[filterIdx].toUpperCase()));
    return;
  }
});
