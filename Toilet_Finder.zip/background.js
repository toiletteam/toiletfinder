// ═══════════════════════════════════════════════
//  BACKGROUND — Context Menu
// ═══════════════════════════════════════════════

const MENU_ID = 'toilet-finder-search';

browser.contextMenus.create({
  id: MENU_ID,
  title: 'Search in Toilet Finder: "%s"',
  contexts: ['selection'],
});

browser.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId !== MENU_ID) return;
  const text = (info.selectionText || '').trim().slice(0, 200);
  if (!text) return;
  browser.storage.local.set({ contextQuery: text, contextQueryTime: Date.now() });
  try { browser.browserAction.openPopup(); } catch(e) {}
});
